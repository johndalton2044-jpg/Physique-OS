/* ============================================================================
   REGION: BOOT — deterministic startup. localStorage mirror paints first; IndexedDB is adopted when ready.
   ============================================================================ */
var _BOOTED=false;
function dailyJobs(){try{var today=todayISO();var last=DB.settings.lastDailyJobs;if(last===today)return;stampPredictions();scorePredictions();captureSnapshot();DB.settings.lastDailyJobs=today;save('daily');if(!DB.settings.lastAutoBackupAt||DB.settings.lastAutoBackupAt.slice(0,10)!==today){writeAutoBackup();DB.settings.lastAutoBackupAt=nowISO();}}catch(e){_q(e);}}
function firstRun(){if(DB.settings.onboarded||DB.observations.length||DB.phases.length)return;DB.settings.onboarded=true;save('onboarded');setTimeout(function(){switchTab('today');toast('Welcome. Set up a profile, or load the demo to see the system with ten weeks of data.',{ms:6000});},200);}
function boot(){
  if(_BOOTED)return;_BOOTED=true;
  var loaded=loadDB();DB=loaded.db;if(loaded.applied&&loaded.applied.length){DB.ledger.migrations=(DB.ledger.migrations||[]).concat(loaded.applied);}
  applySettings();installDispatcher();installHotkeys();
  window.addEventListener('hashchange',function(){var t=location.hash.replace('#','');if(t&&document.getElementById('view-'+t)&&t!==_TAB)switchTab(t);});
  var start=location.hash.replace('#','');switchTab(document.getElementById('view-'+start)?start:'today');
  makeDelegatedControlsFocusable();
  onSave(function(){_memoInvalidate();});
  initDurableStorage().then(function(){return adoptDurableCopy();}).then(function(adopted){if(adopted){_memoInvalidate();applySettings();renderAll();}dailyJobs();renderAll();}).catch(function(e){_q(e);dailyJobs();});
  try{watchOtherTabs();}catch(e){_q(e);}
  storageEstimate().then(function(est){_STORAGE_EST=est;}).catch(_q);
  window.addEventListener('online',function(){renderAll();});window.addEventListener('offline',function(){renderAll();});
  document.addEventListener('visibilitychange',function(){if(document.visibilityState==='visible'){dailyJobs();renderAll();}});
  registerServiceWorker();
  firstRun();
  try{loadFoodManifest().then(function(){if(_TAB==='food'||_TAB==='tools')renderAll();}).catch(function(){});}catch(e){}
}
if(typeof document!=='undefined'&&document.readyState!=='loading')boot();else if(typeof document!=='undefined')document.addEventListener('DOMContentLoaded',boot);
