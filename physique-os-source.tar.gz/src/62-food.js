/* ============================================================================
   REGION: FOOD INTELLIGENCE — USDA FDC as the backbone (Foundation inline; Branded lazy-loaded shards).
   Source provenance and food version travel with every logged item. Historical logs keep the nutrient
   snapshot they were logged with; a database update never rewrites them.
   ============================================================================ */
var FOOD_DATA_BASE='./data/food/';
var _foodCache={};var _foodManifest=null,_foodManifestState='not loaded';
var FOOD_SOURCES=[
  {id:'FDC_FOUNDATION',name:'USDA FoodData Central \u2014 Foundation Foods',org:'USDA ARS',license:'CC0 1.0 (public domain)',version:FOUNDATION_RELEASE,shipped:'inline',rank:3},
  {id:'FDC_BRANDED',name:'USDA FoodData Central \u2014 Branded Foods',org:'USDA / GS1 / Label Insight',license:'CC0 1.0 (public domain)',version:FOUNDATION_RELEASE,shipped:'lazy shards under ./data/food/branded/',rank:2},
  {id:'USER',name:'User-entered foods and recipes',org:'this record',license:'\u2014',version:'\u2014',shipped:'local',rank:8},
  {id:'NIH_DSLD',name:'NIH Dietary Supplement Label Database',org:'NIH ODS',license:'CC0',version:'adapter not yet installed',shipped:'\u2014',rank:5,planned:true},
  {id:'FDC_FNDDS',name:'USDA FNDDS (survey foods and portions)',org:'USDA ARS',license:'CC0',version:'adapter not yet installed',shipped:'\u2014',rank:4,planned:true}
];
function seedFoods(){return memo('seedFoods',function(){return FOUNDATION_SEED.map(function(r){return {kind:'seed',id:'fdc-'+r[0],fdcId:r[0],name:r[1],category:r[2],per100g:r[3],portions:r[4].map(function(p){return {label:p[0],g:p[1],racc:!!p[2]};}),source:'FDC_FOUNDATION',version:FOUNDATION_RELEASE,energySource:r[5]};});});}
var FOOD_SYNONYMS={yoghurt:'yogurt',chikn:'chicken',brest:'breast',mince:'ground',capsicum:'pepper',courgette:'zucchini',aubergine:'eggplant',prawn:'shrimp',rockmelon:'cantaloupe',oats:'oat',eggs:'egg'};
function _stem(t){if(t.length<=3)return t;if(/(oes|ches|shes|sses|xes)$/.test(t))return t.slice(0,-2);if(/ies$/.test(t))return t.slice(0,-3)+'y';if(/[^s]s$/.test(t))return t.slice(0,-1);return t;}
function foodTokens(s){return String(s||'').toLowerCase().normalize('NFKD').replace(/[^a-z0-9%]+/g,' ').split(' ').filter(function(t){return t.length>=2;}).map(function(t){return _stem(FOOD_SYNONYMS[t]||t);});}
function localFoods(){return seedFoods().concat((DB.foods||[]).map(function(f){return Object.assign({kind:'user',source:'USER'},f);}),(DB.recipes||[]).map(function(r){return recipeAsFood(r);}));}
function foodSearchLocal(q,limit){
  var toks=foodTokens(q);if(!toks.length)return [];
  var res=[];localFoods().forEach(function(f){var name=f.name.toLowerCase();var nt=foodTokens(f.name+' '+(f.category||''));var head=foodTokens(f.name.split(',')[0]);var score=0;toks.forEach(function(t){if(head.indexOf(t)>=0)score+=5;else if(nt.indexOf(t)>=0)score+=3;else if(nt.some(function(x){return x.indexOf(t)===0;}))score+=2;else if(name.indexOf(t)>=0)score+=1;else score-=4;});if(score>0)res.push({f:f,score:score+(f.kind==='user'||f.kind==='recipe'?1:0)-name.length/200-(/,\s*(dried|dry|flour|powder)/i.test(f.name)?1.5:0)});});
  res.sort(function(a,b){return b.score-a.score;});return res.slice(0,limit||30).map(function(x){return x.f;});
}
function loadFoodJSON(rel){
  if(_foodCache[rel])return _foodCache[rel];
  if(typeof fetch!=='function'){var e=new Error('food database not reachable in this environment');e.availability=true;return Promise.reject(e);}
  var p=fetch(FOOD_DATA_BASE+rel).then(function(r){if(!r.ok){var e=new Error('HTTP '+r.status+' for '+rel);e.availability=true;throw e;}return r.json();}).catch(function(e){if(e&&!e.availability&&/fetch|network|Failed/i.test(String(e.message)))e.availability=true;throw e;});
  _foodCache[rel]=p;p.catch(function(){delete _foodCache[rel];});return p;
}
function loadFoodManifest(){if(_foodManifest)return Promise.resolve(_foodManifest);_foodManifestState='loading';return loadFoodJSON('manifest.json').then(function(m){_foodManifest=m;_foodManifestState='loaded';return m;}).catch(function(e){_foodManifestState='unavailable: '+(e&&e.message||e);throw e;});}
function _decodePostings(d){var out=[],acc=0;for(var i=0;i<d.length;i++){acc+=d[i];out.push(acc);}return out;}
function brandedRecord(idx,manifest){var per=manifest.branded.recsPerShard;var shard=Math.floor(idx/per);return loadFoodJSON('branded/recs-'+String(shard).padStart(3,'0')+'.json').then(function(arr){var r=arr[idx-shard*per];return r?brandedToFood(r,manifest,idx):null;});}
function brandedToFood(r,manifest,idx){
  var cat=manifest.branded.categories[r[5]]||'';var per={kcal:r[9],protein:r[10],carbs:r[11],fat:r[12],fiber:r[13],sugars:r[14],satfat:r[15],sodium:r[16]};
  var portions=[];if(r[6])portions.push({label:'1 serving ('+(r[8]||(r[6]+' '+(r[7]?'ml':'g')))+')',g:r[6],isMl:!!r[7],serving:true});
  return {kind:'branded',id:'fdc-'+r[0],fdcId:r[0],idx:idx,name:titleCase(r[1]),brand:r[3]||'',owner:r[2]||'',gtin:r[4],category:cat,per100g:per,portions:portions,servingSize:r[6],servingUnit:r[7]?'ml':'g',household:r[8],discontinued:!!r[17],modifiedYear:r[18],versions:r[19],energySource:manifest.branded.energySourceCodes[r[20]]||'label',source:'FDC_BRANDED',version:manifest.databaseVersion};
}
function titleCase(s){return String(s||'').toLowerCase().replace(/(^|\s|[("'-])([a-z])/g,function(m,p,c){return p+c.toUpperCase();});}
function foodSearchBranded(q,limit){
  limit=limit||40;var toks=foodTokens(q);if(!toks.length)return Promise.resolve([]);
  return loadFoodManifest().then(function(m){
    var prefixes=m.branded.idxPrefixes;
    return Promise.all(toks.map(function(t){var pre=t.slice(0,2);if(prefixes.indexOf(pre)<0)return {tok:t,hits:{}};return loadFoodJSON('branded/idx-'+pre.replace(/[^a-z0-9]/g,'_')+'.json').then(function(idx){var hits={};var exact=idx[t];if(exact)_decodePostings(exact).forEach(function(i){hits[i]=3;});var n=0;Object.keys(idx).forEach(function(k){if(k===t||k.indexOf(t)!==0)return;if(n++>400)return;_decodePostings(idx[k]).forEach(function(i){if(!hits[i])hits[i]=1;});});return {tok:t,hits:hits};}).catch(function(e){if(!e||!e.availability)_q(e);return {tok:t,hits:{}};});}))
    .then(function(per){
      var scores={};per[0]&&Object.keys(per[0].hits).forEach(function(i){var ok=true,s=0;per.forEach(function(p){if(!p.hits[i])ok=false;else s+=p.hits[i];});if(ok)scores[i]=s;});
      var ids=Object.keys(scores).map(Number);if(!ids.length)return [];
      ids.sort(function(a,b){return scores[b]-scores[a]||a-b;});
      var top=ids.slice(0,Math.min(limit*3,300));
      return Promise.all(top.map(function(i){return brandedRecord(i,m);})).then(function(foods){
        foods=foods.filter(Boolean).map(function(f){var nt=foodTokens(f.name+' '+f.brand);var s=scores[f.idx]||0;toks.forEach(function(t){if(nt.indexOf(t)>=0)s+=2;});if(f.discontinued)s-=3;if(f.per100g.kcal==null)s-=2;s+=(f.modifiedYear||2017)>=2023?1:0;s-=f.name.length/120;f._score=s;return f;});
        foods.sort(function(a,b){return b._score-a._score;});return foods.slice(0,limit);
      });
    });
  });
}
function lookupGtin(code){
  var c=String(code||'').replace(/\D/g,'');if(!c)return Promise.resolve(null);
  return loadFoodManifest().then(function(m){var key=c.slice(-2).padStart(2,'0');return loadFoodJSON('branded/gtin-'+key+'.json').then(function(g){var idx=g[c];if(idx==null){var padded=c.padStart(14,'0');idx=g[padded];if(idx==null){var k2=Object.keys(g).filter(function(k){return k.replace(/^0+/,'')===c.replace(/^0+/,'');})[0];idx=k2!=null?g[k2]:null;}}return idx==null?null:brandedRecord(idx,m);});});
}
function prefetchFoodDB(onProgress){
  return loadFoodManifest().then(function(m){var files=m.files.map(function(f){return f.file;});var done=0;var chain=Promise.resolve();files.forEach(function(rel){chain=chain.then(function(){return loadFoodJSON(rel).catch(_q).then(function(){done++;if(onProgress)onProgress(done,files.length);});});});return chain.then(function(){return {done:done,total:files.length,bytes:m.totalBytes};});});
}
/* ---- portions: every portion resolves to grams before any nutrient math ---- */
var UNIT_G={g:1,gram:1,grams:1,oz:28.3495,ounce:28.3495,ounces:28.3495,lb:453.592,pound:453.592,pounds:453.592,kg:1000,ml:1,l:1000,cup:240,cups:240,tbsp:15,tablespoon:15,tsp:5,teaspoon:5};
function portionGrams(food,amount,unit){
  amount=num(amount);if(amount==null)return null;
  if(unit==='serving'){var s=(food.portions||[]).filter(function(p){return p.serving||p.racc;})[0]||(food.portions||[])[0];return s?amount*s.g:null;}
  if(unit&&unit.indexOf('portion:')===0){var lab=unit.slice(8);var p=(food.portions||[]).filter(function(x){return x.label===lab;})[0];return p?amount*p.g:null;}
  var f=UNIT_G[unit];if(f==null)return null;return amount*f;
}
function portionOptions(food){
  var opts=[];(food.portions||[]).forEach(function(p){opts.push({value:'portion:'+p.label,label:p.label+' ('+fmtNum(p.g,0)+' g)',approx:false});});
  opts.push({value:'g',label:'grams'},{value:'oz',label:'ounces'});
  if(!(food.portions||[]).some(function(p){return /cup/i.test(p.label);}))opts.push({value:'cup',label:'cup (\u2248240 g, approximate)',approx:true});
  opts.push({value:'tbsp',label:'tbsp (\u224815 g, approximate)',approx:true},{value:'tsp',label:'tsp (\u22485 g, approximate)',approx:true});
  return opts;
}
var NUTRIENT_KEYS=['kcal','protein','carbs','fat','fiber','sugars','satfat','sodium'];
function nutrientsFor(food,grams){var out={};var f=grams/100;NUTRIENT_KEYS.forEach(function(k){var v=food.per100g&&food.per100g[k];out[k]=v==null?null:round(v*f,1);});return out;}
function macroConsistency(food){var p=food.per100g||{};if(p.kcal==null||p.protein==null||p.carbs==null||p.fat==null)return null;var calc=4*p.protein+4*p.carbs+9*p.fat;var diff=calc-p.kcal;return {calc:calc,label:p.kcal,diff:diff,pct:p.kcal?Math.round(100*diff/p.kcal):null,note:Math.abs(diff)>Math.max(25,p.kcal*0.15)?'label energy and 4/4/9 macro energy differ by '+fmtSigned(diff,0)+' kcal/100 g (rounding, fiber or sugar alcohols); the label stays authoritative':null};}
/* ---- recipes ---- */
function recipeTotals(r){var tot={};NUTRIENT_KEYS.forEach(function(k){tot[k]=0;});var g=0;(r.ingredients||[]).forEach(function(i){var n=nutrientsFor(i.food,i.grams);NUTRIENT_KEYS.forEach(function(k){if(n[k]!=null)tot[k]+=n[k];});g+=i.grams;});var per={};var s=r.servings||1;NUTRIENT_KEYS.forEach(function(k){per[k]=round(tot[k]/s,1);});return {totals:tot,perServing:per,gramsTotal:g,gramsPerServing:g/s};}
function recipeAsFood(r){var t=recipeTotals(r);var per100={};NUTRIENT_KEYS.forEach(function(k){per100[k]=t.gramsTotal?round(t.totals[k]/t.gramsTotal*100,2):0;});return {kind:'recipe',id:r.id,name:r.name,category:'Recipe',per100g:per100,portions:[{label:'1 serving',g:round(t.gramsPerServing,1),serving:true}],source:'USER',version:r.updatedAt||r.createdAt,recipe:r};}
function saveRecipe(r){pushUndo('save recipe');if(!r.id){r.id=uid('rcp');r.createdAt=nowISO();DB.recipes.push(r);}else{r.updatedAt=nowISO();var i=DB.recipes.findIndex(function(x){return x.id===r.id;});if(i>=0)DB.recipes[i]=r;else DB.recipes.push(r);}save('recipe');_memoInvalidate();return r;}
function saveUserFood(f){pushUndo('save food');if(!f.id){f.id=uid('food');f.createdAt=nowISO();DB.foods.push(f);}else{f.updatedAt=nowISO();var i=DB.foods.findIndex(function(x){return x.id===f.id;});if(i>=0)DB.foods[i]=f;else DB.foods.push(f);}save('food');_memoInvalidate();return f;}
/* ---- meals + food logs ---- */
var MEALS=['breakfast','lunch','dinner','snacks'];
function foodSnapshot(f){return {kind:f.kind,id:f.id,fdcId:f.fdcId||null,name:f.name,brand:f.brand||'',source:f.source,version:f.version,category:f.category||'',per100g:JSON.parse(JSON.stringify(f.per100g||{})),energySource:f.energySource||null};}
function logFood(o){
  var grams=num(o.grams);if(!grams||grams<=0)throw new Error('portion resolves to zero grams');
  var rec={id:uid('fl'),date:o.date||todayISO(),meal:MEALS.indexOf(o.meal)>=0?o.meal:'snacks',food:foodSnapshot(o.food),grams:round(grams,1),portionLabel:o.portionLabel||(fmtNum(grams,0)+' g'),nutrients:nutrientsFor(o.food,grams),createdAt:nowISO(),source:'manual'};
  if(!o.silent)pushUndo('log food');
  DB.foodLogs.push(rec);syncNutritionObservations(rec.date);if(!o.noSave)save('food-log');return rec;
}
function removeFoodLog(id){var i=DB.foodLogs.findIndex(function(x){return x.id===id;});if(i<0)return false;pushUndo('remove food');var d=DB.foodLogs[i].date;DB.foodLogs.splice(i,1);syncNutritionObservations(d);save('food-log:remove');return true;}
function updateFoodLog(id,grams,meal){var x=DB.foodLogs.filter(function(f){return f.id===id;})[0];if(!x)return null;pushUndo('edit food');x.grams=round(num(grams)||x.grams,1);x.portionLabel=fmtNum(x.grams,0)+' g';x.nutrients=nutrientsFor(x.food,x.grams);if(meal)x.meal=meal;x.updatedAt=nowISO();syncNutritionObservations(x.date);save('food-log:edit');return x;}
function foodLogsOn(date){return (DB.foodLogs||[]).filter(function(f){return f.date===date;});}
function dayNutrition(date){var logs=foodLogsOn(date);var tot={};NUTRIENT_KEYS.forEach(function(k){tot[k]=0;});var byMeal={};MEALS.forEach(function(m){byMeal[m]={items:[],totals:{}};NUTRIENT_KEYS.forEach(function(k){byMeal[m].totals[k]=0;});});logs.forEach(function(l){NUTRIENT_KEYS.forEach(function(k){if(l.nutrients[k]!=null){tot[k]+=l.nutrients[k];byMeal[l.meal].totals[k]+=l.nutrients[k];}});byMeal[l.meal].items.push(l);});return {date:date,items:logs.length,totals:tot,byMeal:byMeal};}
// The bridge: food logs become nutrition observations (source 'food-log'). Manual quick-log entries for the same day take precedence in aggregation.
var FOODLOG_OBS={kcal:'calories',protein:'protein',carbs:'carbs',fat:'fat',fiber:'fiber'};
function syncNutritionObservations(date){
  var day=dayNutrition(date);
  DB.observations.forEach(function(o){if(o.source==='food-log'&&o.date===date&&!o.retracted){o.retracted=true;o.retractedAt=nowISO();o.retractReason='superseded by recalculation';}});
  _memoInvalidate();
  if(!day.items)return;
  Object.keys(FOODLOG_OBS).forEach(function(k){var v=day.totals[k];if(v==null)return;var rec=makeObservation({type:FOODLOG_OBS[k],date:date,value:round(v,0),source:'food-log',quality:'derived',note:day.items+' logged items',meta:{items:day.items}});DB.observations.push(rec);});
  _memoInvalidate();
}
// aggregation override: within dailySeries for nutrition types, manual beats food-log for the same day
(function(){var _orig=dailySeries;dailySeries=function(type,asOfDate,days,opts){var out=_orig(type,asOfDate,days,opts);if(!FOODLOG_TYPES[type])return out;return out.map(function(d){var manual=d.obs.filter(function(o){return o.source!=='food-log';});if(!manual.length||manual.length===d.obs.length)return d;var v=manual.reduce(function(s,o){return s+o.value;},0);return {date:d.date,value:v,n:manual.length,obs:manual,x:d.x,override:'manual entry overrides the food log for this day'};});};})();
var FOODLOG_TYPES={calories:1,protein:1,carbs:1,fat:1,fiber:1};
function recentFoods(limit){var seen={},out=[];(DB.foodLogs||[]).slice().reverse().forEach(function(l){var k=l.food.id;if(seen[k])return;seen[k]=1;out.push(Object.assign({},l.food,{lastGrams:l.grams,lastLabel:l.portionLabel,portions:portionsFromSnapshot(l)}));});return out.slice(0,limit||12);}
function frequentFoods(limit){var c={},ref={};(DB.foodLogs||[]).forEach(function(l){c[l.food.id]=(c[l.food.id]||0)+1;ref[l.food.id]=l;});return Object.keys(c).sort(function(a,b){return c[b]-c[a];}).slice(0,limit||8).map(function(id){var l=ref[id];return Object.assign({},l.food,{count:c[id],lastGrams:l.grams,portions:portionsFromSnapshot(l)});});}
function portionsFromSnapshot(l){var live=localFoods().filter(function(f){return f.id===l.food.id;})[0];return live?live.portions:[{label:l.portionLabel,g:l.grams}];}
function favorites(){return DB.settings.favorites||[];}
function toggleFavorite(food){var favs=favorites();var i=favs.findIndex(function(f){return f.id===food.id;});if(i>=0)favs.splice(i,1);else favs.push(foodSnapshot(food));DB.settings.favorites=favs;save('favorite');return i<0;}
function repeatDay(fromDate,toDate){var logs=foodLogsOn(fromDate);if(!logs.length)return 0;pushUndo('repeat day');logs.forEach(function(l){DB.foodLogs.push({id:uid('fl'),date:toDate,meal:l.meal,food:JSON.parse(JSON.stringify(l.food)),grams:l.grams,portionLabel:l.portionLabel,nutrients:JSON.parse(JSON.stringify(l.nutrients)),createdAt:nowISO(),source:'repeat'});});syncNutritionObservations(toDate);save('food-log:repeat');return logs.length;}
function repeatMeal(fromDate,meal,toDate){var logs=foodLogsOn(fromDate).filter(function(l){return l.meal===meal;});if(!logs.length)return 0;pushUndo('repeat meal');logs.forEach(function(l){DB.foodLogs.push({id:uid('fl'),date:toDate,meal:meal,food:JSON.parse(JSON.stringify(l.food)),grams:l.grams,portionLabel:l.portionLabel,nutrients:JSON.parse(JSON.stringify(l.nutrients)),createdAt:nowISO(),source:'repeat'});});syncNutritionObservations(toDate);save('food-log:repeat');return logs.length;}
/* ---- reference comparison for a day's intake ---- */
function nutritionReference(day){
  var p=prof();var kg=weightKgNow();var out=[];var ph=activePhase()||{};
  var t=day.totals;
  out.push({label:'Protein',value:fmtG(t.protein,0),ref:ph.proteinTarget?('target \u2265'+fmtG(ph.proteinTarget,0)):(kg?('DGA 1.2\u20131.6 g/kg = '+fmtG(kg*1.2,0)+'\u2013'+fmtG(kg*1.6,0)):'\u2014'),tone:ph.proteinTarget?(t.protein>=ph.proteinTarget*0.9?'good':(t.protein>=ph.proteinTarget*0.7?'attention':'negative')):'neutral',cls:ph.proteinTarget?'target':'reference'});
  out.push({label:'Fiber',value:fmtG(t.fiber,0),ref:'DV 28 g \u00b7 AI '+(p.sex==='female'?'25':'38')+' g',tone:t.fiber>=28?'good':(t.fiber>=20?'attention':'neutral'),cls:'reference'});
  var satPct=t.kcal?Math.round(100*t.satfat*9/t.kcal):null;out.push({label:'Saturated fat',value:fmtG(t.satfat,0)+(satPct!=null?(' \u00b7 '+satPct+'% kcal'):''),ref:'DGA \u226410% of calories',tone:satPct==null?'neutral':(satPct<=10?'good':'attention'),cls:'reference'});
  out.push({label:'Sodium',value:fmtNum(t.sodium,0)+' mg',ref:'DGA <2,300 mg (more if very active)',tone:t.sodium<=2300?'good':(t.sodium<=3000?'attention':'negative'),cls:'reference'});
  out.push({label:'Sugars (total)',value:fmtG(t.sugars,0),ref:'added-sugar limit \u226410 g per meal (DGA); total sugars include fruit and dairy',tone:'neutral',cls:'reference'});
  return out;
}
