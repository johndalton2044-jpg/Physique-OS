/* ============================================================================
   REGION: SCHEMA — one versioned document with named collections. Not one unstructured blob:
   every collection has a declared shape (see validateDB) and a migration chain.
   ============================================================================ */
var OBS_TYPES={
  weight:{label:'Body weight',unit:'lb',group:'body',consumers:['weight trend','7/14-day average','TDEE','forecast','goal trajectory','rate of loss'],min:50,max:700,step:0.1},
  waist:{label:'Waist',unit:'in',group:'body',consumers:['waist trend','body-composition estimate','stall diagnosis','fat vs other mass'],min:15,max:80,step:0.1},
  neck:{label:'Neck',unit:'in',group:'body',consumers:['body-composition estimate (circumference model)'],min:8,max:30,step:0.1},
  hip:{label:'Hip',unit:'in',group:'body',consumers:['body-composition estimate (circumference model, female)'],min:20,max:90,step:0.1},
  chest:{label:'Chest',unit:'in',group:'body',consumers:['measurement trend'],min:20,max:80,step:0.1},
  arm:{label:'Upper arm',unit:'in',group:'body',consumers:['measurement trend','lean-mass indicator'],min:6,max:30,step:0.1},
  thigh:{label:'Thigh',unit:'in',group:'body',consumers:['measurement trend','lean-mass indicator'],min:10,max:45,step:0.1},
  bodyfat:{label:'Body fat',unit:'%',group:'body',consumers:['composition estimate cross-check'],min:2,max:70,step:0.1,methods:['DEXA','BIA scale','calipers','Bod Pod','hydrostatic','visual estimate','other']},
  rhr:{label:'Resting heart rate',unit:'bpm',group:'body',consumers:['fitness indicator','recovery signal'],min:30,max:140,step:1},
  calories:{label:'Calories',unit:'kcal',group:'nutrition',consumers:['TDEE','energy balance','calorie adherence','deficit estimate'],min:0,max:15000,step:1},
  protein:{label:'Protein',unit:'g',group:'nutrition',consumers:['protein adherence','muscle-retention risk'],min:0,max:600,step:1},
  carbs:{label:'Carbohydrate',unit:'g',group:'nutrition',consumers:['macro summary','water-noise context'],min:0,max:1500,step:1},
  fat:{label:'Dietary fat',unit:'g',group:'nutrition',consumers:['macro summary','fat floor check'],min:0,max:500,step:1},
  fiber:{label:'Fiber',unit:'g',group:'nutrition',consumers:['fiber adequacy','satiety intervention'],min:0,max:200,step:1},
  water:{label:'Water',unit:'L',group:'nutrition',consumers:['hydration context'],min:0,max:15,step:0.1},
  adherence:{label:'Plan adherence',unit:'%',group:'nutrition',consumers:['adherence confidence','model error vs execution error'],min:0,max:100,step:1},
  hunger:{label:'Hunger',unit:'/10',group:'appetite',consumers:['appetite burden','diet sustainability','over-aggressive check'],min:0,max:10,step:1},
  fullness:{label:'Fullness',unit:'/10',group:'appetite',consumers:['satiety efficiency'],min:0,max:10,step:1},
  cravings:{label:'Cravings',unit:'/10',group:'appetite',consumers:['overeating risk'],min:0,max:10,step:1},
  difficulty:{label:'Diet difficulty',unit:'/10',group:'appetite',consumers:['diet sustainability'],min:0,max:10,step:1},
  steps:{label:'Steps',unit:'steps',group:'activity',consumers:['step baseline','NEAT trend','activity target','TDEE context'],min:0,max:80000,step:1},
  cardio:{label:'Cardio',unit:'min',group:'activity',consumers:['cardio load','recovery interference','activity adherence'],min:0,max:600,step:1,modalities:['incline walk','walk','cycle','elliptical','swim','row','jog','stairs','other']},
  sleep:{label:'Sleep',unit:'h',group:'recovery',consumers:['recovery state','appetite context','over-aggressive check'],min:0,max:16,step:0.1},
  sleepq:{label:'Sleep quality',unit:'/10',group:'recovery',consumers:['recovery state'],min:0,max:10,step:1},
  fatigue:{label:'Fatigue',unit:'/10',group:'recovery',consumers:['recovery state','deload candidate','over-aggressive check'],min:0,max:10,step:1},
  stress:{label:'Stress',unit:'/10',group:'recovery',consumers:['recovery state'],min:0,max:10,step:1},
  soreness:{label:'Soreness',unit:'/10',group:'recovery',consumers:['recovery state','water-noise context'],min:0,max:10,step:1},
  motivation:{label:'Motivation',unit:'/10',group:'recovery',consumers:['adherence risk'],min:0,max:10,step:1},
  supplement:{label:'Supplement',unit:'',group:'supplement',consumers:['supplement adherence','creatine water-weight context'],text:true},
  note:{label:'Observation note',unit:'',group:'note',consumers:['replay narrative','search'],text:true},
  context:{label:'Context tag',unit:'',group:'note',consumers:['interpretation context (travel, illness, new scale)'],text:true,tags:['travel','illness','holiday','high stress','new scale','new program','deload','injury','high sodium','high carbs','poor sleep','alcohol']}
};
var PHASE_TYPES={
  cut:{label:'Cut',objective:'Reduce fat mass while preserving lean tissue and performance.'},
  recomp:{label:'Recomposition',objective:'Hold weight roughly stable while waist falls and strength rises.'},
  lean_gain:{label:'Lean gain',objective:'Add muscle with a small, controlled surplus.'},
  maintenance:{label:'Maintenance',objective:'Find and hold the individual maintenance range; protect against regain.'},
  diet_break:{label:'Diet break',objective:'Planned return to estimated maintenance to restore appetite, recovery and adherence.'},
  transition:{label:'Transition',objective:'Move intake toward maintenance gradually after a cut.'},
  recovery:{label:'Recovery / deload',objective:'Reduce training load to restore performance and recovery.'},
  goal_complete:{label:'Goal complete',objective:'Goal reached; review and choose the next objective.'}
};
function emptyDB(){
  return {
    schemaVersion:SCHEMA_VERSION,appVersion:APP_VERSION,createdAt:nowISO(),revision:0,instance:uid('inst'),
    profile:{name:'',age:null,sex:'',heightIn:null,startWeightLb:null,goalWeightLb:null,goalType:'',targetDate:'',trainingExperience:'',activityBaseline:'',dietPreference:'',equipment:'',schedule:'',sleepTargetH:null,createdAt:nowISO(),updatedAt:null},
    phases:[],observations:[],sessions:[],foodLogs:[],foods:[],recipes:[],
    decisions:[],interventions:[],predictions:[],experiments:[],negatives:[],snapshots:[],archive:[],notes:[],
    models:{calibration:{},versions:{}},
    settings:{units:'imperial',textScale:'M',density:'cozy',contrast:'normal',motion:'auto',theme:'dark',showModels:true,webfonts:false,folds:{},lastBackupAt:null,onboarded:false,program:'fullbody3'},
    ledger:{migrations:[],saves:0,lastSaveAt:null,corruptions:[]},
    demo:{active:false,generatedAt:null,scenario:null}
  };
}
/* Migrations: SCHEMA n → n+1. Never just bump the number. Each step is idempotent and non-destructive. */
var MIGRATIONS=[
  // {from:1,to:2,note:'...',fn:function(db){...;return db;}}
];
function migrate(db){
  var applied=[];var v=db.schemaVersion||1;
  MIGRATIONS.forEach(function(m){if(m.from===v){try{db=m.fn(db)||db;db.schemaVersion=m.to;v=m.to;applied.push(m.from+'\u2192'+m.to+' '+m.note);}catch(e){_q(e);}}});
  // structural backfill for any collection missing (older or partial documents)
  var fresh=emptyDB();
  Object.keys(fresh).forEach(function(k){if(db[k]===undefined)db[k]=fresh[k];});
  ['phases','observations','sessions','foodLogs','foods','recipes','decisions','interventions','predictions','experiments','negatives','snapshots','archive','notes'].forEach(function(k){if(!Array.isArray(db[k]))db[k]=[];});
  if(!db.settings||typeof db.settings!=='object')db.settings=fresh.settings;
  Object.keys(fresh.settings).forEach(function(k){if(db.settings[k]===undefined)db.settings[k]=fresh.settings[k];});
  if(!db.profile||typeof db.profile!=='object')db.profile=fresh.profile;
  if(!db.ledger||typeof db.ledger!=='object')db.ledger=fresh.ledger;
  if(!db.models||typeof db.models!=='object')db.models=fresh.models;
  if(!db.demo||typeof db.demo!=='object')db.demo=fresh.demo;
  db.schemaVersion=SCHEMA_VERSION;db.appVersion=APP_VERSION;
  if(applied.length){db.ledger.migrations=(db.ledger.migrations||[]).concat(applied.map(function(a){return {at:nowISO(),step:a};}));}
  return {db:db,applied:applied};
}
/* Validation for restore/import: reject malformed input, never execute imported content. */
function validateDB(obj){
  var errors=[],warnings=[],counts={};
  if(!obj||typeof obj!=='object'||Array.isArray(obj)){return {ok:false,errors:['Not a Physique OS document'],warnings:[],counts:{}};}
  if(obj.app&&obj.app!==APP_NAME)warnings.push('Document was written by "'+obj.app+'"');
  if(obj.schemaVersion!=null&&(typeof obj.schemaVersion!=='number'||obj.schemaVersion>SCHEMA_VERSION))errors.push('Schema version '+obj.schemaVersion+' is newer than this app supports ('+SCHEMA_VERSION+')');
  var lists=['phases','observations','sessions','foodLogs','foods','recipes','decisions','interventions','predictions','experiments','negatives','snapshots','archive','notes'];
  lists.forEach(function(k){if(obj[k]!=null&&!Array.isArray(obj[k]))errors.push(k+' must be a list');else counts[k]=(obj[k]||[]).length;});
  var seen={};var L=function(k){return Array.isArray(obj[k])?obj[k]:[];};
  L('observations').forEach(function(o,i){
    if(!o||typeof o!=='object'){errors.push('observation #'+i+' malformed');return;}
    if(!o.type||!OBS_TYPES[o.type])warnings.push('observation #'+i+' has unknown type "'+o.type+'"');
    if(!isValidISO(o.date))errors.push('observation #'+i+' has an invalid date');
    else if(daysBetween(todayISO(),o.date)>1)warnings.push('observation #'+i+' is dated in the future ('+o.date+')');
    if(o.id){if(seen[o.id])errors.push('duplicate observation id '+o.id);seen[o.id]=1;}
    var t=OBS_TYPES[o.type];
    if(t&&!t.text){var v=num(o.value);if(v==null)errors.push('observation #'+i+' ('+o.type+') has a non-numeric value');else if(v<t.min||v>t.max)warnings.push('observation #'+i+' ('+o.type+'='+v+') is outside the plausible range');}
  });
  L('predictions').forEach(function(p,i){if(!p||!p.madeAt||!p.dueDate)errors.push('prediction #'+i+' lacks madeAt/dueDate');});
  L('sessions').forEach(function(s,i){if(!s||!isValidISO(s.date))errors.push('session #'+i+' has an invalid date');if(s&&!Array.isArray(s.sets))errors.push('session #'+i+' lacks sets');});
  if(obj.profile&&typeof obj.profile!=='object')errors.push('profile malformed');
  return {ok:!errors.length,errors:errors,warnings:warnings,counts:counts};
}

/* ============================================================================
   REGION: STORAGE — IndexedDB is authoritative; localStorage mirrors for the synchronous first paint.
   Writes go to both. If the mirror is full or evicted, IndexedDB carries on. Reads are synchronous
   from the in-memory document; the boot path adopts the durable copy if it is newer.
   ============================================================================ */
var IDB_NAME='physique-os',IDB_STORE='kv',IDB_VERSION=1;
var LS_KEY='physiqueOS_db_v1',LS_META='physiqueOS_meta_v1';
var DB=null;
var _IDB=null,_IDB_READY=false,_IDB_QUEUE=[],_IDB_STATE='not started',_IDB_LAST_ERROR=null;
var _SAVE_STATE={ok:true,lastError:null,lastAt:null,failures:0};
function idbAvailable(){try{return !!(globalThis.indexedDB&&typeof globalThis.indexedDB.open==='function');}catch(e){return false;}}
function openDb(){
  return new Promise(function(resolve,reject){
    if(!idbAvailable())return reject(new Error('IndexedDB unavailable'));
    var req;try{req=indexedDB.open(IDB_NAME,IDB_VERSION);}catch(e){return reject(e);}
    req.onupgradeneeded=function(){try{var db=req.result;if(!db.objectStoreNames.contains(IDB_STORE))db.createObjectStore(IDB_STORE);}catch(e){}};
    req.onsuccess=function(){resolve(req.result);};
    req.onerror=function(){reject(req.error||new Error('open failed'));};
    req.onblocked=function(){reject(new Error('IndexedDB blocked by another tab'));};
  });
}
function idbGet(db,key){return new Promise(function(res,rej){try{var r=db.transaction(IDB_STORE,'readonly').objectStore(IDB_STORE).get(key);r.onsuccess=function(){res(r.result===undefined?null:r.result);};r.onerror=function(){rej(r.error);};}catch(e){rej(e);}});}
function idbSet(db,key,val){return new Promise(function(res,rej){try{var r=db.transaction(IDB_STORE,'readwrite').objectStore(IDB_STORE).put(val,key);r.onsuccess=function(){res(true);};r.onerror=function(){rej(r.error);};}catch(e){rej(e);}});}
function idbDel(db,key){return new Promise(function(res,rej){try{var r=db.transaction(IDB_STORE,'readwrite').objectStore(IDB_STORE).delete(key);r.onsuccess=function(){res(true);};r.onerror=function(){rej(r.error);};}catch(e){rej(e);}});}
function idbKeys(db){return new Promise(function(res,rej){try{var r=db.transaction(IDB_STORE,'readonly').objectStore(IDB_STORE).getAllKeys();r.onsuccess=function(){res(r.result||[]);};r.onerror=function(){rej(r.error);};}catch(e){rej(e);}});}
function idbStatus(){return {state:_IDB_STATE,ready:_IDB_READY,queued:_IDB_QUEUE.length,durable:_IDB_READY?'IndexedDB':'localStorage only',lastError:_IDB_LAST_ERROR};}
var _idbTimer=null;
function _idbFlush(){
  if(!_IDB_READY||!_IDB)return;
  var pending=_IDB_QUEUE.splice(0,_IDB_QUEUE.length);
  var last={};pending.forEach(function(j){last[j.key]=j.val;}); // collapse bursts: one durable write per key
  Object.keys(last).forEach(function(k){idbSet(_IDB,k,last[k]).then(function(){_SAVE_STATE.ok=true;_SAVE_STATE.lastAt=nowISO();}).catch(function(err){_IDB_LAST_ERROR=String(err&&err.message||err);_SAVE_STATE.failures++;_q(err);});});
}
function idbWrite(key,val){_IDB_QUEUE.push({key:key,val:val});if(_IDB_READY){clearTimeout(_idbTimer);_idbTimer=setTimeout(_idbFlush,150);}}
function initDurableStorage(){
  if(!idbAvailable()){_IDB_STATE='unavailable \u2014 localStorage only';return Promise.resolve(idbStatus());}
  _IDB_STATE='opening';
  return openDb().then(function(db){_IDB=db;_IDB_READY=true;_IDB_STATE='ready';_idbFlush();return idbStatus();})
    .catch(function(err){_IDB_STATE='failed: '+String(err&&err.message||err);_IDB_LAST_ERROR=_IDB_STATE;_q(err);return idbStatus();});
}
function serializeDB(){return JSON.stringify(DB);}
function _lsGet(k){try{return localStorage.getItem(k);}catch(e){return null;}}
function _lsSet(k,v){try{localStorage.setItem(k,v);return true;}catch(e){return false;}}
function loadDB(){
  var raw=_lsGet(LS_KEY);
  if(raw){
    try{var obj=JSON.parse(raw);if(obj&&typeof obj==='object'){var m=migrate(obj);return {db:m.db,source:'localStorage',applied:m.applied};}}
    catch(e){_q(e);var fresh=emptyDB();fresh.ledger.corruptions.push({at:nowISO(),where:'localStorage',bytes:raw.length,note:'unparseable; raw copy preserved under physiqueOS_corrupt'});try{idbWrite('corrupt-'+Date.now(),raw);}catch(x){}return {db:fresh,source:'fresh-after-corruption',applied:[]};}
  }
  return {db:emptyDB(),source:'fresh',applied:[]};
}
var _saveListeners=[];
function onSave(fn){_saveListeners.push(fn);}
function save(label){
  try{
    DB.revision=(DB.revision||0)+1;DB.ledger.saves=(DB.ledger.saves||0)+1;DB.ledger.lastSaveAt=nowISO();DB.appVersion=APP_VERSION;
    var s=serializeDB();
    var mirrored=_lsSet(LS_KEY,s);
    _lsSet(LS_META,JSON.stringify({revision:DB.revision,instance:DB.instance,at:DB.ledger.lastSaveAt}));
    idbWrite('db',s);
    if(!mirrored&&!_IDB_READY){_SAVE_STATE.ok=false;_SAVE_STATE.lastError='localStorage rejected the write and IndexedDB is not ready';}
    else{_SAVE_STATE.ok=true;_SAVE_STATE.lastError=null;_SAVE_STATE.lastAt=DB.ledger.lastSaveAt;}
    _memoInvalidate();
    _saveListeners.forEach(function(f){try{f(label);}catch(e){_q(e);}});
    return true;
  }catch(e){_q(e);_SAVE_STATE.ok=false;_SAVE_STATE.lastError=String(e&&e.message||e);return false;}
}
function adoptDurableCopy(){
  if(!_IDB)return Promise.resolve(false);
  return idbGet(_IDB,'db').then(function(v){
    if(!v)return false;
    var mirror=_lsGet(LS_KEY);
    if(mirror===v)return false;
    try{var obj=JSON.parse(v);if(!obj||typeof obj!=='object')return false;
      if(DB&&(obj.revision||0)<=(DB.revision||0)&&mirror)return false; // mirror is newer or equal
      var m=migrate(obj);DB=m.db;_lsSet(LS_KEY,v);_memoInvalidate();return true;
    }catch(e){_q(e);return false;}
  }).catch(function(e){_q(e);return false;});
}
function writeAutoBackup(){ // daily durable snapshot for corruption recovery
  try{if(!_IDB_READY)return;var key='autobackup-'+todayISO();idbWrite(key,serializeDB());
    idbKeys(_IDB).then(function(keys){keys.filter(function(k){return /^autobackup-/.test(k);}).sort().slice(0,-7).forEach(function(k){idbDel(_IDB,k).catch(_q);});}).catch(_q);
  }catch(e){_q(e);}
}
function listAutoBackups(){if(!_IDB)return Promise.resolve([]);return idbKeys(_IDB).then(function(keys){return keys.filter(function(k){return /^autobackup-/.test(k);}).sort().reverse();}).catch(function(e){_q(e);return [];});}
function storageEstimate(){try{if(navigator.storage&&navigator.storage.estimate)return navigator.storage.estimate();}catch(e){}return Promise.resolve(null);}
/* multi-tab: another tab saved a newer revision → reload the document rather than overwrite it */
function watchOtherTabs(){
  try{window.addEventListener('storage',function(ev){
    if(ev.key!==LS_META||!ev.newValue)return;
    try{var meta=JSON.parse(ev.newValue);if(meta.instance===DB.instance)return;if((meta.revision||0)>(DB.revision||0)){var l=loadDB();DB=l.db;_memoInvalidate();if(typeof renderAll==='function')renderAll(true);if(typeof toast==='function')toast('Reloaded changes saved in another tab');}}catch(e){_q(e);}
  });}catch(e){_q(e);}
}

/* ============================================================================
   REGION: UNDO — reversible mutations via document snapshots. Operates on state, never the DOM.
   ============================================================================ */
var _undoStack=[],UNDO_MAX=30;
function pushUndo(label){try{_undoStack.push({label:label||'change',at:nowISO(),snap:serializeDB()});if(_undoStack.length>UNDO_MAX)_undoStack.shift();}catch(e){_q(e);}}
function canUndo(){return _undoStack.length>0;}
function undoLabel(){return _undoStack.length?_undoStack[_undoStack.length-1].label:null;}
function undo(){
  var u=_undoStack.pop();if(!u)return null;
  try{var obj=JSON.parse(u.snap);var m=migrate(obj);var keepRev=DB.revision;DB=m.db;DB.revision=keepRev;save('undo');return u.label;}catch(e){_q(e);return null;}
}
function clearUndo(){_undoStack=[];}

/* memo cache for derived state: invalidated on every save or "today" change */
var _MEMO={};function _memoInvalidate(){_MEMO={};}
function memo(key,fn){if(Object.prototype.hasOwnProperty.call(_MEMO,key))return _MEMO[key];var v=fn();_MEMO[key]=v;return v;}
