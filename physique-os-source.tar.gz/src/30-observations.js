/* ============================================================================
   REGION: OBSERVATIONS — Layer 1. What was actually measured, logged or reported.
   Append-only: a correction is a new record that supersedes the old one; deletion is a retraction with
   metadata. Every read accepts an as-of date so replay can reconstruct what the system knew.
   ============================================================================ */
var _ASOF=null; // set during replay; null = now
function asOf(){return _ASOF||todayISO();}
function withAsOf(date,fn){var prev=_ASOF,prevNow=_NOW_OVERRIDE;_ASOF=date;_NOW_OVERRIDE=date;_memoInvalidate();try{return fn();}finally{_ASOF=prev;_NOW_OVERRIDE=prevNow;_memoInvalidate();}}
// visibility rule for replay: the record must be dated on/before the as-of day AND have been created by then
function _visible(o,date){if(!o||o.retracted)return false;if(o.correctedBy)return false;if(o.date>date)return false;if(o.createdAt&&o.createdAt.slice(0,10)>date)return false;return true;}
function activePhase(date){date=date||asOf();var ph=(DB.phases||[]).filter(function(p){return p.status!=='archived'&&p.startDate<=date&&(!p.endDate||p.endDate>=date);});return ph.length?ph[ph.length-1]:null;}
function phaseAt(date){var ph=(DB.phases||[]).filter(function(p){return p.startDate<=date&&(!p.endDate||p.endDate>=date);});return ph.length?ph[ph.length-1]:null;}
function makeObservation(o){
  var t=OBS_TYPES[o.type];if(!t)throw new Error('unknown observation type '+o.type);
  var date=o.date||todayISO();if(!isValidISO(date))throw new Error('invalid date');
  var value=t.text?String(o.value==null?'':o.value).trim():num(o.value);
  if(!t.text&&value==null)throw new Error('value required');
  var ph=phaseAt(date);
  return {id:uid('obs'),type:o.type,date:date,at:o.at||nowISO(),value:value,unit:t.unit,method:o.method||null,source:o.source||'manual',quality:o.quality||(o.source==='demo'?'demo':(o.method==='estimate'?'estimated':'measured')),
    note:o.note?String(o.note).slice(0,500):'',meta:o.meta||null,phaseId:ph?ph.id:null,supersedes:o.supersedes||null,correctedBy:null,retracted:false,createdAt:o.createdAt||nowISO(),flags:[]};
}
function addObservation(o,opts){
  opts=opts||{};
  var rec=makeObservation(o);
  var t=OBS_TYPES[rec.type];
  if(!t.text){
    if(rec.value<t.min||rec.value>t.max)rec.flags.push('outside plausible range');
    var out=outlierCheck(rec.type,rec.value,rec.date);if(out.outlier)rec.flags.push('possible outlier: '+out.note);
  }
  if(!opts.silent)pushUndo('log '+t.label);
  DB.observations.push(rec);_memoInvalidate();
  if(!opts.noSave)save('observation:'+rec.type);
  return rec;
}
function correctObservation(id,newValue,reason){
  var old=DB.observations.filter(function(x){return x.id===id;})[0];if(!old)return null;
  pushUndo('correct '+OBS_TYPES[old.type].label);
  var rec=makeObservation({type:old.type,date:old.date,value:newValue,method:old.method,source:old.source,note:old.note,meta:old.meta,supersedes:old.id});
  rec.correction={of:old.id,originalValue:old.value,reason:reason||'',at:nowISO()};
  old.correctedBy=rec.id;
  DB.observations.push(rec);_memoInvalidate();save('correction');return rec;
}
function retractObservation(id,reason){
  var o=DB.observations.filter(function(x){return x.id===id;})[0];if(!o)return false;
  pushUndo('delete '+OBS_TYPES[o.type].label);o.retracted=true;o.retractedAt=nowISO();o.retractReason=reason||'';_memoInvalidate();save('retract');return true;
}
function outlierCheck(type,value,date){
  try{var s=dailySeries(type,date,21).filter(function(d){return d.date<date;}).map(function(d){return d.value;});
    if(s.length<5)return {outlier:false};
    var m=median(s),d=mad(s)||0;var thresh=Math.max(d*3.5/0.6745,(OBS_TYPES[type].step||1)*(type==='weight'?4:type==='waist'?1.5:3));
    if(Math.abs(value-m)>thresh)return {outlier:true,note:'differs from the recent median ('+fmtNum(m,1)+') by more than usual variation'};
  }catch(e){_q(e);}
  return {outlier:false};
}
function obsOf(type,opts){
  opts=opts||{};var date=opts.asOf||asOf();
  var out=DB.observations.filter(function(o){return o.type===type&&_visible(o,date)&&(!opts.phaseId||o.phaseId===opts.phaseId)&&(!opts.from||o.date>=opts.from);});
  out.sort(function(a,b){return a.date<b.date?-1:(a.date>b.date?1:(a.at<b.at?-1:1));});
  return out;
}
function latestObs(type,opts){var l=obsOf(type,opts);return l.length?l[l.length-1]:null;}
var SUM_TYPES={calories:1,protein:1,carbs:1,fat:1,fiber:1,water:1,steps:1,cardio:1,sleep:1};
// one value per day: sums for intake/activity streams, means for measurements and ratings
function dailySeries(type,asOfDate,days,opts){
  opts=opts||{};asOfDate=asOfDate||asOf();
  var key='ds:'+type+':'+asOfDate+':'+days+':'+(opts.phaseId||'')+':'+(opts.from||'');
  return memo(key,function(){
    var from=days?addDays(asOfDate,-(days-1)):null;if(opts.from&&(!from||opts.from>from))from=opts.from;
    var list=obsOf(type,{asOf:asOfDate,phaseId:opts.phaseId,from:from});
    var by={};list.forEach(function(o){if(!by[o.date])by[o.date]={date:o.date,vals:[],obs:[]};by[o.date].vals.push(o.value);by[o.date].obs.push(o);});
    return Object.keys(by).sort().map(function(d){var b=by[d];var v=SUM_TYPES[type]?b.vals.reduce(function(s,x){return s+x;},0):mean(b.vals);return {date:d,value:v,n:b.vals.length,obs:b.obs,x:daysBetween(from||b.date,d)};});
  });
}
function seriesWindow(type,days,asOfDate){return dailySeries(type,asOfDate||asOf(),days);}
function coverage(type,days,asOfDate){var s=seriesWindow(type,days,asOfDate);return {logged:s.length,days:days,pct:days?Math.round(100*s.length/days):0};}
function missingness(days){
  days=days||14;var out={};
  ['weight','calories','protein','steps','sleep','waist','hunger','fatigue'].forEach(function(t){var c=coverage(t,days);out[t]={logged:c.logged,days:days,pct:c.pct,state:c.pct>=85?'complete':(c.pct>=50?'partial':(c.pct>0?'sparse':'none'))};});
  var lastTrain=(DB.sessions||[]).filter(function(s){return s.date<=asOf();}).sort(function(a,b){return a.date<b.date?1:-1;})[0];
  out.training={lastDate:lastTrain?lastTrain.date:null,sessions14:(DB.sessions||[]).filter(function(s){return s.date<=asOf()&&daysBetween(s.date,asOf())<14;}).length};
  return out;
}
function detectAnomalies(){
  var found=[];var today=todayISO();var seen={};
  DB.observations.forEach(function(o){
    if(o.retracted)return;var t=OBS_TYPES[o.type];if(!t)return;
    if(o.date>addDays(today,1))found.push({kind:'future timestamp',obs:o,detail:o.date});
    if(!t.text){if(o.value<t.min||o.value>t.max)found.push({kind:'implausible value',obs:o,detail:fmtNum(o.value,1)+' '+t.unit});if(o.value<0)found.push({kind:'negative value',obs:o,detail:o.value});}
    var k=o.type+'|'+o.date+'|'+o.value;if(!SUM_TYPES[o.type]){if(seen[k]&&!o.correctedBy&&!o.supersedes)found.push({kind:'duplicate observation',obs:o,detail:t.label+' '+o.date});seen[k]=1;}
  });
  var byDate={};(DB.sessions||[]).forEach(function(s){var k=s.date+'|'+(s.name||'');if(byDate[k])found.push({kind:'duplicate training session',obs:s,detail:s.date+' '+(s.name||'')});byDate[k]=1;});
  var tags=obsOf('context');var scale=tags.filter(function(o){return /new scale|scale changed/i.test(o.value);});
  scale.forEach(function(o){found.push({kind:'device change',obs:o,detail:'scale changed on '+shortDate(o.date)+' \u2014 weight trend treats this as a discontinuity'});});
  return found;
}
function contextTags(days){return obsOf('context',{from:addDays(asOf(),-(days||14))});}
function hasContext(re,days){return contextTags(days).some(function(o){return re.test(o.value);});}

/* ---- phases ---- */
function startPhase(p){
  var ph={id:uid('phase'),type:p.type||'cut',startDate:p.startDate||todayISO(),endDate:null,status:'active',objective:p.objective||(PHASE_TYPES[p.type||'cut']||{}).objective,
    calorieTarget:num(p.calorieTarget),proteinTarget:num(p.proteinTarget),fatFloor:num(p.fatFloor),fiberTarget:num(p.fiberTarget),stepTarget:num(p.stepTarget),cardioSessions:num(p.cardioSessions),cardioMinutes:num(p.cardioMinutes),trainingSessions:num(p.trainingSessions),sleepTargetH:num(p.sleepTargetH),
    targetRateLo:num(p.targetRateLo),targetRateHi:num(p.targetRateHi),goalWeightLb:num(p.goalWeightLb),targetDate:p.targetDate||'',
    successCriteria:p.successCriteria||'',stopCriteria:p.stopCriteria||'',transitionCriteria:p.transitionCriteria||'',
    startingState:p.startingState||null,targetSource:p.targetSource||'user',createdAt:nowISO(),notes:p.notes||''};
  pushUndo('start phase');
  (DB.phases||[]).forEach(function(x){if(x.status==='active'&&!x.endDate){x.endDate=addDays(ph.startDate,-1)<x.startDate?x.startDate:addDays(ph.startDate,-1);x.status='ended';}});
  DB.phases.push(ph);save('phase:start');return ph;
}
function endPhase(id,outcome){
  var ph=DB.phases.filter(function(p){return p.id===id;})[0];if(!ph)return null;
  pushUndo('end phase');ph.endDate=todayISO();ph.status='ended';ph.outcome=outcome||'';
  try{archivePhase(ph);}catch(e){_q(e);}
  save('phase:end');return ph;
}
function updatePhase(id,patch){var ph=DB.phases.filter(function(p){return p.id===id;})[0];if(!ph)return null;pushUndo('edit phase');Object.keys(patch).forEach(function(k){ph[k]=patch[k];});ph.updatedAt=nowISO();save('phase:edit');return ph;}
function phaseWeek(ph,date){if(!ph)return null;return weekOf(date||asOf(),ph.startDate);}
function phaseLabel(ph){return ph?((PHASE_TYPES[ph.type]||{}).label||ph.type):'No phase';}

/* ---- training sessions (sets are observations of load × reps × RIR) ---- */
function addSession(s){
  var rec={id:uid('sess'),date:s.date||todayISO(),name:s.name||'Session',template:s.template||null,durationMin:num(s.durationMin),notes:s.notes||'',source:s.source||'manual',createdAt:s.createdAt||nowISO(),
    sets:(s.sets||[]).filter(function(x){return x&&x.exercise&&num(x.reps)!=null;}).map(function(x){return {exercise:String(x.exercise).trim(),load:num(x.load),reps:num(x.reps),rir:num(x.rir),note:x.note||''};}),
    phaseId:(phaseAt(s.date||todayISO())||{}).id||null,retracted:false};
  if(!s.silent)pushUndo('log training');
  DB.sessions.push(rec);_memoInvalidate();if(!s.noSave)save('session');return rec;
}
function retractSession(id){var s=DB.sessions.filter(function(x){return x.id===id;})[0];if(!s)return false;pushUndo('delete session');s.retracted=true;s.retractedAt=nowISO();_memoInvalidate();save('session:retract');return true;}
function sessionsOf(opts){opts=opts||{};var date=opts.asOf||asOf();return (DB.sessions||[]).filter(function(s){return !s.retracted&&s.date<=date&&(!s.createdAt||s.createdAt.slice(0,10)<=date)&&(!opts.from||s.date>=opts.from);}).sort(function(a,b){return a.date<b.date?-1:1;});}
