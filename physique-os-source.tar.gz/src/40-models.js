/* ============================================================================
   REGION: MODELS — Layer 2 (state) and Layer 3 (models). Pure functions over observations.
   Every model is registered with an epistemic class, version, inputs, minimum evidence, assumptions and
   failure conditions. Below the minimum, a model returns {status:'insufficient'} — never a number.
   ============================================================================ */
var CLASSES={
  MEASURED:'read directly from an instrument or entered as a measurement',
  DERIVED:'computed from measurements by a fixed formula',
  HEURISTIC:'a rule of thumb \u2014 useful, not fitted to this person',
  PRIOR:'a generic starting assumption from population evidence, not from this record',
  EMPIRICAL:'fitted to this person\u2019s own logged intake and measurements',
  CALIBRATED:'corrected by comparing past predictions with what actually happened',
  PREDICTIVE:'a forecast of something that has not happened yet'
};
var MODELS=[
  {id:'weight_avg',name:'Rolling weight average',cls:'DERIVED',version:'1.0',inputs:['weight'],minN:4,assumes:['weigh-ins under similar conditions'],failsWhen:['fewer than 4 of the last 7 days logged','scale changed inside the window'],output:'7- and 14-day mean of daily weight'},
  {id:'weight_trend',name:'Weight trend',cls:'DERIVED',version:'1.1',inputs:['weight'],minN:7,assumes:['Theil\u2013Sen slope is robust to a few odd weigh-ins','a 14-day window separates noise from tissue change'],failsWhen:['fewer than 7 weigh-ins spanning 10+ days','scale change in window','extreme water disturbance (illness, travel, high sodium)'],output:'slope in lb/week with residual noise and confidence'},
  {id:'water_noise',name:'Water-noise probability',cls:'HEURISTIC',version:'1.0',inputs:['weight volatility','context tags','phase age','carbohydrate swings'],minN:5,assumes:['glycogen, sodium, bowel contents and training inflammation move scale weight without changing fat mass'],failsWhen:['no context logged and volatility is ambiguous'],output:'low / medium / high'},
  {id:'tdee_prior',name:'TDEE prior (Mifflin-St Jeor \u00d7 activity)',cls:'PRIOR',version:'1.0',inputs:['age','sex','height','weight','activity baseline'],minN:0,assumes:['population RMR equation; activity multiplier is a rough band'],failsWhen:['profile incomplete'],output:'starting estimate with \u00b1 ~15% uncertainty; replaced as personal evidence accumulates'},
  {id:'tdee_personal',name:'Personal energy model',cls:'EMPIRICAL',version:'1.2',inputs:['calories','weight trend','logging coverage','adherence'],minN:14,assumes:['tissue lost/gained averages about 3,200 kcal/lb (\u00b1500) at higher body fat','intake logging error of about \u00b110% unless adherence data says otherwise','no large change in activity inside the window'],failsWhen:['under 14 usable days','intake coverage under 70%','weight trend insufficient','rapid phase transition or extreme water disturbance'],output:'estimated TDEE with interval, evidence count and calibration status'},
  {id:'energy_balance',name:'Energy balance',cls:'DERIVED',version:'1.0',inputs:['mean intake','estimated TDEE'],minN:7,assumes:['inherits TDEE uncertainty'],failsWhen:['TDEE insufficient'],output:'observed deficit/surplus estimate'},
  {id:'bodycomp_circ',name:'Body-fat estimate (circumference model)',cls:'HEURISTIC',version:'1.0',inputs:['waist','neck','height','hip (female)'],minN:1,assumes:['U.S. Navy circumference equation; population fit, \u00b13\u20134% typical error'],failsWhen:['waist or neck missing','measurements older than 30 days','method inconsistency'],output:'body-fat range and fat/lean mass ranges'},
  {id:'fat_vs_other',name:'Fat vs other mass change',cls:'HEURISTIC',version:'1.0',inputs:['weight trend','waist trend','phase age','water noise'],minN:14,assumes:['a falling waist alongside a falling trend indicates fat loss is the dominant component'],failsWhen:['fewer than 2 waist measurements 10+ days apart','first 14 days of a cut (glycogen/water)'],output:'plausible split, never a precise fat number'},
  {id:'rate_band',name:'Sustainable rate band',cls:'HEURISTIC',version:'1.0',inputs:['current weight','phase'],minN:0,assumes:['0.5\u20131% body weight/week; tighter as body mass falls to protect lean tissue'],failsWhen:['no weight'],output:'recommended lb/week range for the current weight zone'},
  {id:'goal_traj',name:'Goal trajectory',cls:'PREDICTIVE',version:'1.0',inputs:['7-day average','goal weight','trend','deadline'],minN:7,assumes:['current trend persists, which it will not exactly; interval widens with horizon'],failsWhen:['trend insufficient','trend not converging on goal'],output:'required rate, status, projected date range'},
  {id:'weight_forecast',name:'Weight forecast',cls:'PREDICTIVE',version:'1.0',inputs:['7-day average','trend','residual noise'],minN:7,assumes:['linear trend over 7\u201328 days; interval = residual noise + slope uncertainty'],failsWhen:['trend insufficient','phase change inside horizon'],output:'point and interval at 7/14/28 days; stamped to the ledger before outcomes'},
  {id:'e1rm',name:'Estimated 1RM',cls:'DERIVED',version:'1.0',inputs:['load','reps'],minN:1,assumes:['Epley/Brzycki/Lander/Lombardi/Mayhew consensus; reliability falls above ~10 reps'],failsWhen:['reps > 15','load missing'],output:'e1RM consensus with estimator spread'},
  {id:'strength_trend',name:'Strength trend',cls:'DERIVED',version:'1.0',inputs:['sessions','e1RM per exercise'],minN:4,assumes:['comparable exercises across sessions'],failsWhen:['fewer than 4 exposures of an exercise','program change'],output:'improving / stable / declining per exercise and overall'},
  {id:'recovery',name:'Recovery state',cls:'HEURISTIC',version:'1.0',inputs:['sleep','sleep quality','fatigue','soreness','stress'],minN:3,assumes:['subjective ratings are honest and roughly consistent'],failsWhen:['fewer than 3 ratings in 7 days'],output:'good / acceptable / strained / poor / unknown with the signals that drove it'},
  {id:'appetite',name:'Appetite burden',cls:'HEURISTIC',version:'1.0',inputs:['hunger','cravings','fullness','difficulty'],minN:3,assumes:['ratings reflect daily experience'],failsWhen:['no ratings'],output:'low / moderate / high'},
  {id:'muscle_risk',name:'Muscle-retention risk',cls:'HEURISTIC',version:'1.0',inputs:['strength trend','protein adherence','rate of loss','recovery','training consistency'],minN:7,assumes:['strength and protein are the strongest available proxies; scale weight is not muscle'],failsWhen:['no training record','no protein record'],output:'low / medium / high / insufficient'},
  {id:'adherence',name:'Adherence',cls:'DERIVED',version:'1.0',inputs:['calories','protein','steps','sessions','sleep','plan targets'],minN:3,assumes:['unlogged days are unknown, not zero'],failsWhen:['no plan targets'],output:'per-stream adherence, never one collapsed score'},
  {id:'data_trust',name:'Data trust',cls:'DERIVED',version:'1.0',inputs:['coverage','freshness','consistency','anomalies'],minN:0,assumes:['confidence of any model cannot exceed the trust of its inputs'],failsWhen:['\u2014'],output:'per-stream trust with reasons'},
  {id:'met_energy',name:'Activity energy (MET)',cls:'DERIVED',version:'1.0',inputs:['modality','duration','body weight'],minN:1,assumes:['2024 Compendium METs are population averages; \u00b120%'],failsWhen:['modality unknown'],output:'estimated kcal for a session, never measured expenditure'}
];
function modelById(id){return MODELS.filter(function(m){return m.id===id;})[0]||null;}
function insufficient(model,need,extra){var o={status:'insufficient',confidence:'insufficient',model:model,need:need||[],note:'insufficient observations'};if(extra)Object.keys(extra).forEach(function(k){o[k]=extra[k];});return o;}
function prof(){return DB.profile||{};}
function weightKgNow(){var w=currentWeight();return w.value!=null?lbToKg(w.value):(prof().startWeightLb?lbToKg(prof().startWeightLb):null);}

/* ---- weight ---- */
function currentWeight(){var o=latestObs('weight');if(!o)return {value:null,obs:null};return {value:o.value,date:o.date,obs:o,fresh:freshness('weight',o.date)};}
function weightAverages(){
  var s7=seriesWindow('weight',7),s14=seriesWindow('weight',14);
  var a7=s7.length>=4?mean(s7.map(function(d){return d.value;})):null,a14=s14.length>=7?mean(s14.map(function(d){return d.value;})):null;
  return {avg7:a7,n7:s7.length,avg14:a14,n14:s14.length,last:s7.length?s7[s7.length-1]:null,status:a7==null?'insufficient':'ok',need:a7==null?[(4-s7.length)+' more weigh-ins this week']:[]};
}
function weightTrend(windowDays,asOfDate){
  windowDays=windowDays||14;
  var s=dailySeries('weight',asOfDate||asOf(),windowDays);
  var pts=s.map(function(d){return {x:d.x,y:d.value};});
  var span=s.length?daysBetween(s[0].date,s[s.length-1].date):0;
  var res={model:'weight_trend',window:windowDays,n:s.length,span:span};
  if(s.length<7||span<10)return insufficient('weight_trend',[(Math.max(0,7-s.length))+' more weigh-ins over '+Math.max(0,10-span)+' more days'],res);
  var ts=theilSen(pts),ol=ols(pts);
  var perWeek=ts.slope*7;
  var noise=ol.residSd;var slopeSe=ol.se!=null?ol.se*7:null;
  var deviceChange=hasContext(/new scale|scale changed/i,windowDays);
  var conf='low';
  if(s.length>=12&&span>=13&&noise!=null&&noise<1.5&&!deviceChange)conf='high';else if(s.length>=9&&!deviceChange)conf='medium';
  if(slopeSe!=null&&Math.abs(perWeek)<slopeSe*1.2&&conf==='high')conf='medium'; // slope indistinguishable from flat at high noise
  res.status='ok';res.slopePerWeek=perWeek;res.slopeSe=slopeSe;res.residSd=noise;res.r2=ol.r2;res.lo=slopeSe!=null?perWeek-1.96*slopeSe:null;res.hi=slopeSe!=null?perWeek+1.96*slopeSe:null;res.confidence=conf;res.deviceChange=deviceChange;res.intercept=ts.intercept;res.first=s[0].date;res.last=s[s.length-1].date;
  res.direction=Math.abs(perWeek)<0.25?'flat':(perWeek<0?'falling':'rising');
  return res;
}
function waterNoise(){
  var s=seriesWindow('weight',14);var vals=s.map(function(d){return d.value;});
  var vol=null;if(vals.length>=5){var diffs=[];for(var i=1;i<vals.length;i++)diffs.push(Math.abs(vals[i]-vals[i-1]));vol=median(diffs);}
  var reasons=[];var score=0;
  var w=currentWeight().value||prof().startWeightLb||200;
  if(vol!=null&&vol>w*0.006){score+=2;reasons.push('day-to-day swings of ~'+fmtWeight(vol)+' exceed usual scale noise');}
  var ph=activePhase();if(ph&&ph.type==='cut'&&daysBetween(ph.startDate,asOf())<14){score+=2;reasons.push('first two weeks of a cut: glycogen and water leave first');}
  if(hasContext(/sodium|carb|alcohol|travel|holiday/i,5)){score+=2;reasons.push('recent sodium, carbohydrate, alcohol or travel context');}
  var creat=obsOf('supplement').filter(function(o){return /creatine/i.test(o.value);});var creatStart=creat.length?creat[0].date:null;
  if(hasContext(/creatine started/i,10)||(creatStart&&daysBetween(creatStart,asOf())<=10)){score+=1;reasons.push('creatine started recently: intracellular water can add scale weight');}
  var sore=seriesWindow('soreness',3);if(sore.length&&mean(sore.map(function(d){return d.value;}))>=7){score+=1;reasons.push('high soreness: training inflammation retains water');}
  var carbs=seriesWindow('carbs',7);if(carbs.length>=4){var cs=sd(carbs.map(function(d){return d.value;}));if(cs&&cs>80){score+=1;reasons.push('carbohydrate intake swinging by ~'+fmtNum(cs,0)+' g/day');}}
  if(vals.length<5)return {status:'insufficient',level:'unknown',reasons:['fewer than 5 weigh-ins'],volatility:vol};
  return {status:'ok',level:score>=4?'high':(score>=2?'medium':'low'),reasons:reasons.length?reasons:['no noise drivers detected'],volatility:vol,score:score};
}
/* ---- energy ---- */
function bmrPrior(){
  var p=prof();var w=currentWeight().value||p.startWeightLb;
  if(!w||!p.heightIn||!p.age||!p.sex)return insufficient('tdee_prior',['age, sex, height and a weight']);
  var kg=lbToKg(w),cm=inToCm(p.heightIn);
  var bmr=10*kg+6.25*cm-5*p.age+(p.sex==='male'?5:-161);
  return {status:'ok',bmr:bmr,weightLb:w};
}
var ACTIVITY_FACTORS={sedentary:{f:1.2,label:'sedentary (desk work, little walking)'},light:{f:1.375,label:'light (some walking, light exercise 1\u20133 days)'},moderate:{f:1.55,label:'moderate (on feet part of the day or exercise 3\u20135 days)'},active:{f:1.725,label:'active (physical job or hard exercise 6\u20137 days)'},very:{f:1.9,label:'very active (heavy labor plus training)'}};
function tdeePrior(){
  var b=bmrPrior();if(b.status!=='ok')return b;
  var af=ACTIVITY_FACTORS[prof().activityBaseline||'light']||ACTIVITY_FACTORS.light;
  var t=b.bmr*af.f;
  return {status:'ok',model:'tdee_prior',cls:'PRIOR',value:t,lo:t*0.85,hi:t*1.15,bmr:b.bmr,factor:af.f,factorLabel:af.label,confidence:'low',note:'population equation \u00d7 activity band'};
}
var TISSUE_KCAL_PER_LB=3200,TISSUE_KCAL_SD=500;
function tdeePersonal(windowDays,asOfDate){
  windowDays=windowDays||28;var date=asOfDate||asOf();
  var cal=dailySeries('calories',date,windowDays);
  var need=[];
  var covPct=Math.round(100*cal.length/windowDays);
  var tr=weightTrend(windowDays,date);
  var res={model:'tdee_personal',window:windowDays,intakeDays:cal.length,coverage:covPct};
  if(cal.length<14)need.push((14-cal.length)+' more days of intake logging');
  if(covPct<70)need.push('intake coverage above 70% (now '+covPct+'%)');
  if(tr.status!=='ok')need=need.concat(tr.need||['a usable weight trend']);
  if(need.length)return insufficient('tdee_personal',need,res);
  var intake=mean(cal.map(function(d){return d.value;}));
  var adh=seriesWindow('adherence',windowDays);var adhMean=adh.length>=3?mean(adh.map(function(d){return d.value;})):null;
  var logErr=adhMean!=null?(adhMean>=90?0.08:(adhMean>=75?0.12:0.18)):0.12;
  var perDay=tr.slopePerWeek/7;
  var tdee=intake-perDay*TISSUE_KCAL_PER_LB;
  var seSlope=(tr.slopeSe!=null?tr.slopeSe/7:Math.abs(perDay)*0.5);
  var varTot=Math.pow(seSlope*TISSUE_KCAL_PER_LB,2)+Math.pow(perDay*TISSUE_KCAL_SD,2)+Math.pow(intake*logErr,2)/cal.length*4;
  var half=1.96*Math.sqrt(varTot);
  var conf='low';if(cal.length>=28&&covPct>=85&&tr.confidence==='high')conf='high';else if(cal.length>=21&&covPct>=75&&tr.confidence!=='low')conf='medium';
  var trust=dataTrust();if(confRank(trust.overall.level==='high'?'high':(trust.overall.level==='moderate'?'medium':'low'))<confRank(conf))conf=trust.overall.level==='moderate'?'medium':'low';
  res.status='ok';res.cls=cal.length>=21&&covPct>=75?'EMPIRICAL':'BLENDED';res.value=tdee;res.lo=tdee-half;res.hi=tdee+half;res.intake=intake;res.trendPerWeek=tr.slopePerWeek;res.confidence=conf;res.logErr=logErr;res.trend=tr;res.n=cal.length;
  return res;
}
function tdeeEstimate(){
  return memo('tdee',function(){
    var prior=tdeePrior(),emp=tdeePersonal(28);
    var cal=tdeeCalibration();
    if(emp.status==='ok'){
      var w=emp.n/(emp.n+14);var v=prior.status==='ok'?w*emp.value+(1-w)*prior.value:emp.value;
      var lo=prior.status==='ok'?w*emp.lo+(1-w)*prior.lo:emp.lo,hi=prior.status==='ok'?w*emp.hi+(1-w)*prior.hi:emp.hi;
      var cls=emp.cls==='EMPIRICAL'&&w>=0.6?'EMPIRICAL':'BLENDED';var adjusted=false;
      if(cal.status==='ok'&&cal.n>=3){var adj=clamp(cal.bias,-300,300);v=v-adj;lo=lo-adj;hi=hi-adj;adjusted=true;if(cls==='EMPIRICAL')cls='CALIBRATED';}
      return {status:'ok',cls:cls,value:v,lo:lo,hi:hi,confidence:emp.confidence,empirical:emp,prior:prior,weight:w,calibration:cal,adjusted:adjusted,maturity:cls==='CALIBRATED'?'calibrated by outcomes':(cls==='EMPIRICAL'?'personalized':(adjusted?'personalizing (outcome-adjusted)':'personalizing')),n:emp.n,coverage:emp.coverage,asOf:asOf()};
    }
    if(prior.status==='ok')return {status:'ok',cls:'PRIOR',value:prior.value,lo:prior.lo,hi:prior.hi,confidence:'low',prior:prior,empirical:emp,need:emp.need,maturity:'generic prior',n:0,asOf:asOf()};
    return insufficient('tdee_prior',['profile: age, sex, height, weight'],{empiricalNeed:emp.need});
  });
}
function tdeeCalibration(){ // from scored TDEE-implied predictions: bias = mean signed error of weight forecasts converted to kcal
  var scored=(DB.predictions||[]).filter(function(p){return p.subject==='weight14'&&p.status==='scored'&&p.error!=null&&p.madeAt.slice(0,10)<=asOf();});
  if(scored.length<3)return {status:'insufficient',n:scored.length,need:[(3-scored.length)+' more scored 14-day forecasts']};
  var err=mean(scored.map(function(p){return p.error;})); // actual - predicted, lb over 14 days
  var biasKcal=err/14*TISSUE_KCAL_PER_LB; // positive error → lost less than predicted → TDEE lower than assumed
  return {status:'ok',n:scored.length,biasLb14:err,bias:biasKcal,mae:mean(scored.map(function(p){return Math.abs(p.error);}))};
}
function energyBalance(){
  var t=tdeeEstimate();var cal=seriesWindow('calories',14);
  if(t.status!=='ok'||cal.length<7)return insufficient('energy_balance',t.status!=='ok'?(t.need||[]):[(7-cal.length)+' more intake days'],{tdee:t});
  var intake=mean(cal.map(function(d){return d.value;}));var bal=intake-t.value;
  return {status:'ok',intake:intake,tdee:t,balance:bal,lo:intake-t.hi,hi:intake-t.lo,confidence:t.confidence,n:cal.length,cls:t.cls==='PRIOR'?'HEURISTIC':'DERIVED'};
}
/* ---- body composition ---- */
function bodyComp(){
  var p=prof();var waist=latestObs('waist'),neck=latestObs('neck'),hip=latestObs('hip');
  var measured=latestObs('bodyfat');
  var out={measured:measured?{value:measured.value,method:measured.method||'unspecified',date:measured.date,fresh:freshness('bodyfat',measured.date)}:null};
  var need=[];if(!waist)need.push('a waist measurement');if(!neck)need.push('a neck measurement');if(!p.heightIn)need.push('height');if(p.sex==='female'&&!hip)need.push('a hip measurement');
  if(need.length){out.estimate=insufficient('bodycomp_circ',need);return out;}
  var h=p.heightIn,w=waist.value,n=neck.value;var bf;
  if(p.sex==='female'){var hp=hip.value;bf=163.205*Math.log10(w+hp-n)-97.684*Math.log10(h)-78.387;}else bf=86.010*Math.log10(w-n)-70.041*Math.log10(h)+36.76;
  if(!isFinite(bf))return {measured:out.measured,estimate:insufficient('bodycomp_circ',['measurements produce an out-of-domain result'])};
  var stale=freshness('waist',waist.date).state==='stale'||freshness('neck',neck.date).state==='stale';
  var wt=weightAverages().avg7||currentWeight().value;
  var lo=clamp(bf-3.5,2,70),hi=clamp(bf+3.5,2,70);
  out.estimate={status:'ok',model:'bodycomp_circ',cls:'HEURISTIC',bf:bf,lo:lo,hi:hi,confidence:stale?'low':'medium',stale:stale,waist:waist,neck:neck,hip:hip,
    fatLo:wt?wt*lo/100:null,fatHi:wt?wt*hi/100:null,leanLo:wt?wt*(1-hi/100):null,leanHi:wt?wt*(1-lo/100):null,weightBasis:wt};
  return out;
}
function waistTrend(days){
  days=days||28;var s=dailySeries('waist',asOf(),days);
  if(s.length<2||daysBetween(s[0].date,s[s.length-1].date)<10)return insufficient('fat_vs_other',['2 waist measurements at least 10 days apart'],{n:s.length});
  var pts=s.map(function(d){return {x:d.x,y:d.value};});var ts=theilSen(pts);
  var perWeek=ts.slope*7;var delta=s[s.length-1].value-s[0].value;
  return {status:'ok',perWeek:perWeek,delta:delta,n:s.length,first:s[0],last:s[s.length-1],direction:Math.abs(perWeek)<0.1?'flat':(perWeek<0?'falling':'rising'),confidence:s.length>=4?'medium':'low'};
}
function fatVsOther(){
  var tr=weightTrend(28),wt=waistTrend(28),wn=waterNoise();var ph=activePhase();
  var need=[];if(tr.status!=='ok')need=need.concat(tr.need||['weight trend']);if(wt.status!=='ok')need=need.concat(wt.need||['waist trend']);
  if(ph&&ph.type==='cut'&&daysBetween(ph.startDate,asOf())<14)need.push('the first 14 days of the cut to pass (water and glycogen dominate early loss)');
  if(need.length)return insufficient('fat_vs_other',need);
  var totalChange=tr.slopePerWeek*4; // over ~28 days
  var waistDown=wt.direction==='falling';
  var fatFrac;
  if(waistDown&&tr.direction==='falling')fatFrac=[0.65,0.9];else if(tr.direction==='falling')fatFrac=[0.4,0.8];else if(tr.direction==='flat'&&waistDown)fatFrac=null;else fatFrac=[0.2,0.6];
  if(wn.level==='high'&&fatFrac)fatFrac=[fatFrac[0]-0.15,fatFrac[1]-0.05];
  var verdict=fatFrac?('estimated fat-loss component '+fmtWeight(Math.abs(totalChange)*fatFrac[0])+'\u2013'+fmtWeight(Math.abs(totalChange)*fatFrac[1])+' of '+fmtWeight(Math.abs(totalChange))+' over 4 weeks'):'weight flat while waist falls: a recomposition-compatible signal; the split cannot be quantified from a tape and a scale';
  return {status:'ok',cls:'HEURISTIC',totalChange:totalChange,fatFrac:fatFrac,verdict:verdict,waist:wt,trend:tr,waterNoise:wn,confidence:minConf(tr.confidence,wt.confidence==='medium'&&wn.level!=='high'?'medium':'low')};
}
/* ---- rate bands and goal ---- */
function rateBand(weightLb,phaseType){
  if(weightLb==null)return null;
  if(phaseType&&phaseType!=='cut')return {lo:-0.25,hi:0.25,label:'stable',zone:'maintenance'};
  var b;
  if(weightLb>250)b={lo:1.5,hi:2.5,zone:'above 250 lb \u00b7 fat loss dominant'};else if(weightLb>230)b={lo:1.25,hi:2.0,zone:'230\u2013250 lb \u00b7 fat loss + retention'};else if(weightLb>210)b={lo:1.0,hi:1.75,zone:'210\u2013230 lb \u00b7 recomposition'};else if(weightLb>190)b={lo:0.75,hi:1.5,zone:'190\u2013210 lb \u00b7 preservation'};else b={lo:0.5,hi:1.0,zone:'under 190 lb \u00b7 composition'};
  var pct={lo:weightLb*0.005,hi:weightLb*0.01};
  return {lo:-b.hi,hi:-b.lo,label:fmtRateRange(-b.hi,-b.lo),zone:b.zone,pctBand:pct,cls:'HEURISTIC'};
}
function targetRate(){
  var ph=activePhase();var w=weightAverages().avg7||currentWeight().value;
  if(ph&&ph.targetRateLo!=null&&ph.targetRateHi!=null)return {lo:Math.min(ph.targetRateLo,ph.targetRateHi),hi:Math.max(ph.targetRateLo,ph.targetRateHi),source:'user target',cls:'MEASURED',band:rateBand(w,ph.type)};
  var b=rateBand(w,ph?ph.type:'cut');if(!b)return null;return {lo:b.lo,hi:b.hi,source:'system recommendation for this weight zone',cls:'HEURISTIC',band:b};
}
function goalTrajectory(){
  var p=prof();var ph=activePhase();var goal=(ph&&ph.goalWeightLb)||p.goalWeightLb;var deadline=(ph&&ph.targetDate)||p.targetDate;
  var wa=weightAverages();var cur=wa.avg7||currentWeight().value;var tr=weightTrend(14);
  if(!goal||cur==null)return insufficient('goal_traj',[!goal?'a goal weight':'','a weight'].filter(Boolean));
  var remaining=cur-goal;var out={status:'ok',model:'goal_traj',cls:'PREDICTIVE',goal:goal,current:cur,remaining:remaining,deadline:deadline||null,trend:tr};
  var band=targetRate();out.band=band;
  if(deadline){var weeks=daysBetween(asOf(),deadline)/7;out.weeksLeft=weeks;out.requiredRate=weeks>0?-remaining/weeks:null;
    if(band&&out.requiredRate!=null){var req=Math.abs(out.requiredRate),hiAbs=Math.abs(band.lo);out.requiredVsBand=req>hiAbs*1.3?'very aggressive':(req>hiAbs?'aggressive':(req<Math.abs(band.hi)?'gentle':'within band'));}}
  if(tr.status==='ok'){
    if(remaining>0&&tr.slopePerWeek<-0.1){var wks=remaining/(-tr.slopePerWeek);out.projectedWeeks=wks;out.projectedDate=addDays(asOf(),Math.round(wks*7));
      if(tr.lo!=null&&tr.hi!=null){var fast=tr.lo<0?remaining/(-tr.lo):null,slow=tr.hi<0?remaining/(-tr.hi):null;out.projectedEarliest=fast!=null?addDays(asOf(),Math.round(fast*7)):null;out.projectedLatest=slow!=null?addDays(asOf(),Math.round(slow*7)):null;}
      if(deadline&&out.requiredRate!=null){out.status2=out.requiredVsBand==='very aggressive'?'unrealistic':(tr.slopePerWeek<=out.requiredRate*1.05?'ahead':(tr.slopePerWeek<=out.requiredRate*0.85?'on track':'behind'));}
      else out.status2='converging';
      out.confidence=tr.confidence==='high'?'medium':'low';
    } else {out.status2=remaining<=0?'at goal':'not converging';out.confidence=tr.confidence==='insufficient'?'insufficient':'low';}
  } else {out.status2='insufficient data';out.confidence='insufficient';out.need=tr.need;}
  return out;
}
function weightForecast(horizonDays){
  var tr=weightTrend(14);var wa=weightAverages();var base=wa.avg7;
  if(tr.status!=='ok'||base==null)return insufficient('weight_forecast',tr.need||['7-day average'],{horizonDays:horizonDays});
  var weeks=horizonDays/7;var point=base+tr.slopePerWeek*weeks;
  var slopeUnc=tr.slopeSe!=null?tr.slopeSe*weeks:Math.abs(tr.slopePerWeek)*0.5*weeks;
  var noise=tr.residSd!=null?tr.residSd:1.0;
  var half=Math.sqrt(Math.pow(1.5*slopeUnc,2)+Math.pow(noise,2))+0.45*weeks;
  var conf=tr.confidence==='high'?(horizonDays<=14?'medium':'low'):'low';
  return {status:'ok',model:'weight_forecast',cls:'PREDICTIVE',horizonDays:horizonDays,point:point,lo:point-half,hi:point+half,base:base,trend:tr,confidence:conf,dueDate:addDays(asOf(),horizonDays),assumptions:['current 14-day trend continues','no phase or intervention change inside the horizon','interval combines scale noise and slope uncertainty']};
}
/* ---- training ---- */
var E1RM={epley:function(w,r){return w*(1+r/30);},brzycki:function(w,r){return r>=37?null:w*36/(37-r);},lander:function(w,r){return w*100/(101.3-2.67123*r);},lombardi:function(w,r){return w*Math.pow(r,0.10);},mayhew:function(w,r){return w*100/(52.2+41.9*Math.exp(-0.055*r));}};
function e1rm(load,reps){if(load==null||reps==null||reps<1)return null;if(reps===1)return {value:load,lo:load,hi:load,reliability:'measured'};var vals=Object.keys(E1RM).map(function(k){return E1RM[k](load,reps);}).filter(function(v){return v!=null&&isFinite(v);});if(!vals.length)return null;return {value:median(vals),lo:Math.min.apply(null,vals),hi:Math.max.apply(null,vals),reliability:reps>12?'low (high-rep estimate)':(reps>8?'moderate':'good')};}
function normExercise(n){return String(n||'').toLowerCase().replace(/\s+/g,' ').trim();}
function exerciseHistory(name){
  var key=normExercise(name);var out=[];
  sessionsOf().forEach(function(s){var best=null,vol=0,sets=0;(s.sets||[]).forEach(function(x){if(normExercise(x.exercise)!==key)return;sets++;if(x.load!=null&&x.reps!=null){vol+=x.load*x.reps;var e=e1rm(x.load,x.reps);if(e&&(!best||e.value>best.value))best=e;}});if(sets)out.push({date:s.date,sessionId:s.id,best:best,volume:vol,sets:sets});});
  return out;
}
function strengthTrend(){
  var sess=sessionsOf();if(sess.length<2)return insufficient('strength_trend',[(4-sess.length)+' more sessions'],{sessions:sess.length});
  var counts={};sess.forEach(function(s){(s.sets||[]).forEach(function(x){var k=normExercise(x.exercise);if(!k)return;counts[k]=(counts[k]||0)+1;});});
  var names=Object.keys(counts).sort(function(a,b){return counts[b]-counts[a];}).slice(0,6);
  var per=[];names.forEach(function(k){var h=exerciseHistory(k).filter(function(x){return x.best;});if(h.length<4){per.push({exercise:k,status:'insufficient',n:h.length,need:(4-h.length)+' more exposures'});return;}
    var recent=h.slice(-3).map(function(x){return x.best.value;}),prior=h.slice(-6,-3).map(function(x){return x.best.value;});
    var pct=prior.length?(mean(recent)-mean(prior))/mean(prior)*100:null;var dir=pct==null?'stable':(pct>2?'improving':(pct<-2.5?'declining':'stable'));
    var consec=0;for(var i=h.length-1;i>0;i--){if(h[i].best.value<h[i-1].best.value)consec++;else break;}
    var priorMean=prior.length?mean(prior):null;var sustained=priorMean!=null&&recent.length===3&&recent.every(function(v){return v<priorMean;})&&pct!=null&&pct<=-4;
    per.push({exercise:k,status:'ok',n:h.length,pct:pct,direction:dir,last:h[h.length-1].best,consecutiveDeclines:consec,sustainedDecline:sustained,history:h});});
  var ok=per.filter(function(x){return x.status==='ok';});
  if(!ok.length)return insufficient('strength_trend',['4+ exposures of the same exercise'],{per:per,sessions:sess.length});
  var dec=ok.filter(function(x){return x.direction==='declining';}).length,imp=ok.filter(function(x){return x.direction==='improving';}).length;
  var overall=dec>ok.length/2?'declining':(imp>ok.length/2?'improving':(dec>0&&dec>=imp?'mixed, some decline':'stable'));
  var maxConsec=Math.max.apply(null,ok.map(function(x){return x.consecutiveDeclines;}));
  var sustainedCount=ok.filter(function(x){return x.sustainedDecline;}).length;
  return {status:'ok',cls:'DERIVED',overall:overall,per:per,declining:dec,improving:imp,tracked:ok.length,maxConsecutiveDeclines:maxConsec,sustainedCount:sustainedCount,confidence:ok.length>=3?'medium':'low'};
}
function trainingState(){
  var s14=sessionsOf({from:addDays(asOf(),-13)}),s7=sessionsOf({from:addDays(asOf(),-6)});
  var ph=activePhase();var planned=ph&&ph.trainingSessions?ph.trainingSessions:null;
  var hard=0,sets=0,vol=0;s7.forEach(function(s){(s.sets||[]).forEach(function(x){sets++;if(x.rir==null||x.rir<=3)hard++;if(x.load&&x.reps)vol+=x.load*x.reps;});});
  var last=sessionsOf().slice(-1)[0]||null;
  var adherence=planned?Math.round(100*Math.min(1,(s14.length/2)/planned)):null;
  return {sessions7:s7.length,sessions14:s14.length,perWeek:s14.length/2,planned:planned,adherence:adherence,sets7:sets,hardSets7:hard,volume7:vol,last:last,lastFresh:last?freshness('training',last.date):null,strength:strengthTrend(),consistency:adherence==null?'no plan':(adherence>=85?'consistent':(adherence>=60?'partial':'low'))};
}
/* ---- recovery / appetite ---- */
function recoveryState(){
  var target=(activePhase()||{}).sleepTargetH||prof().sleepTargetH||7.5;
  var m=function(t,d){var s=seriesWindow(t,d||7);return s.length?{mean:mean(s.map(function(x){return x.value;})),n:s.length,last:s[s.length-1]}:null;};
  var sl=m('sleep'),sq=m('sleepq'),fa=m('fatigue'),so=m('soreness'),st=m('stress'),mo=m('motivation');
  var n=[sl,sq,fa,so,st].filter(Boolean).reduce(function(a,x){return a+x.n;},0);
  var signals=[];
  if(sl&&sl.mean<target-0.5)signals.push({key:'sleep',text:'sleep averaging '+fmtH(sl.mean)+' vs '+fmtH(target)+' target',severity:sl.mean<target-1.5?2:1});
  if(sq&&sq.mean<=4)signals.push({key:'sleepq',text:'sleep quality low ('+fmtNum(sq.mean,1)+'/10)',severity:1});
  if(fa&&fa.mean>=7)signals.push({key:'fatigue',text:'fatigue high ('+fmtNum(fa.mean,1)+'/10)',severity:fa.mean>=8?2:1});
  if(so&&so.mean>=7)signals.push({key:'soreness',text:'soreness high ('+fmtNum(so.mean,1)+'/10)',severity:1});
  if(st&&st.mean>=7)signals.push({key:'stress',text:'stress high ('+fmtNum(st.mean,1)+'/10)',severity:1});
  if(mo&&mo.mean<=3)signals.push({key:'motivation',text:'motivation low ('+fmtNum(mo.mean,1)+'/10)',severity:1});
  if(n<3)return {status:'insufficient',level:'unknown',signals:signals,n:n,need:[(3-n)+' more recovery ratings this week'],sleep:sl,fatigue:fa,soreness:so,stress:st,sleepq:sq,target:target};
  var score=signals.reduce(function(a,s){return a+s.severity;},0);
  var level=score===0?'good':(score===1?'acceptable':(score<=3?'strained':'poor'));
  return {status:'ok',cls:'HEURISTIC',level:level,score:score,signals:signals,n:n,sleep:sl,sleepq:sq,fatigue:fa,soreness:so,stress:st,motivation:mo,target:target,confidence:n>=7?'medium':'low'};
}
function appetiteState(){
  var m=function(t){var s=seriesWindow(t,7);return s.length?{mean:mean(s.map(function(x){return x.value;})),n:s.length}:null;};
  var hu=m('hunger'),cr=m('cravings'),fu=m('fullness'),df=m('difficulty');
  var n=[hu,cr,fu,df].filter(Boolean).reduce(function(a,x){return a+x.n;},0);
  if(n<3)return {status:'insufficient',level:'unknown',n:n,need:[(3-n)+' more appetite ratings this week'],hunger:hu,cravings:cr,fullness:fu,difficulty:df};
  var burden=0;if(hu&&hu.mean>=7)burden+=2;else if(hu&&hu.mean>=5)burden+=1;if(cr&&cr.mean>=7)burden+=1;if(fu&&fu.mean<=3)burden+=1;if(df&&df.mean>=7)burden+=1;
  var level=burden>=3?'high':(burden>=1?'moderate':'low');
  return {status:'ok',cls:'HEURISTIC',level:level,burden:burden,hunger:hu,cravings:cr,fullness:fu,difficulty:df,n:n,sustainability:level==='high'?'at risk':(level==='moderate'?'watch':'acceptable'),confidence:n>=7?'medium':'low'};
}
/* ---- adherence: separate dimensions, unlogged = unknown ---- */
function adherenceState(days){
  days=days||14;var ph=activePhase()||{};var out={days:days};
  var cal=seriesWindow('calories',days);
  out.logging={pct:Math.round(100*cal.length/days),n:cal.length};
  if(ph.calorieTarget&&cal.length){var ok=cal.filter(function(d){return Math.abs(d.value-ph.calorieTarget)/ph.calorieTarget<=0.10;}).length;out.calories={pct:Math.round(100*ok/cal.length),n:cal.length,target:ph.calorieTarget,mean:mean(cal.map(function(d){return d.value;}))};}
  var pr=seriesWindow('protein',days);
  if(ph.proteinTarget&&pr.length){var okp=pr.filter(function(d){return d.value>=ph.proteinTarget*0.9;}).length;out.protein={pct:Math.round(100*okp/pr.length),n:pr.length,target:ph.proteinTarget,mean:mean(pr.map(function(d){return d.value;}))};}
  var st=seriesWindow('steps',days);
  if(st.length){out.steps={n:st.length,mean:mean(st.map(function(d){return d.value;})),target:ph.stepTarget||null,pct:ph.stepTarget?Math.round(100*st.filter(function(d){return d.value>=ph.stepTarget*0.9;}).length/st.length):null};}
  var sl=seriesWindow('sleep',days);var tgt=ph.sleepTargetH||prof().sleepTargetH;
  if(sl.length&&tgt)out.sleep={n:sl.length,pct:Math.round(100*sl.filter(function(d){return d.value>=tgt-0.5;}).length/sl.length),target:tgt,mean:mean(sl.map(function(d){return d.value;}))};
  var tr=trainingState();out.training={pct:tr.adherence,perWeek:tr.perWeek,planned:tr.planned};
  var rep=seriesWindow('adherence',days);if(rep.length)out.reported={mean:mean(rep.map(function(d){return d.value;})),n:rep.length};
  var cardio=seriesWindow('cardio',days);out.cardio={sessions:cardio.reduce(function(a,d){return a+d.n;},0),minutes:cardio.reduce(function(a,d){return a+d.value;},0),plannedSessions:ph.cardioSessions?ph.cardioSessions*days/7:null};
  var fields=['calories','protein','steps','sleep'].filter(function(k){return out[k]&&out[k].pct!=null;});
  out.overallNote=fields.length?fields.map(function(k){return k+' '+out[k].pct+'%';}).join(' \u00b7 '):'no plan targets to compare against';
  out.confidence=out.logging.pct>=80&&(out.reported?out.reported.n>=5:true)?'high':(out.logging.pct>=50?'medium':'low');
  return out;
}
/* ---- data trust ---- */
function dataTrust(){
  return memo('trust',function(){
    var streams={};var reasons=[];
    var w=coverage('weight',14),c=coverage('calories',14),p=coverage('protein',14),s=coverage('steps',14),sl=coverage('sleep',14);
    var lvl=function(pct){return pct>=85?'high':(pct>=60?'moderate':(pct>0?'low':'insufficient'));};
    streams.weight={level:lvl(w.pct),detail:w.logged+' of 14 days'};
    streams.nutrition={level:lvl(c.pct),detail:c.logged+' of 14 days logged'+(p.logged<c.logged?(' \u00b7 protein on '+p.logged):'')};
    streams.activity={level:lvl(s.pct),detail:s.logged+' of 14 days'};
    streams.sleep={level:lvl(sl.pct),detail:sl.logged+' of 14 days'};
    var ts=trainingState();streams.training={level:ts.sessions14>=4?'high':(ts.sessions14>=2?'moderate':(ts.sessions14?'low':'insufficient')),detail:ts.sessions14+' sessions in 14 days'};
    var waist=latestObs('waist');streams.waist={level:!waist?'insufficient':(freshness('waist',waist.date).state==='fresh'?'high':(freshness('waist',waist.date).state==='aging'?'moderate':'low')),detail:waist?('last '+ageLabel(waist.date)):'never measured'};
    var bc=bodyComp();streams.composition={level:bc.measured?(bc.measured.fresh.state==='stale'?'low':'moderate'):(bc.estimate&&bc.estimate.status==='ok'?'low':'insufficient'),detail:bc.measured?('measured by '+bc.measured.method+' '+ageLabel(bc.measured.date)):(bc.estimate&&bc.estimate.status==='ok'?'circumference estimate only':'no measurements')};
    var an=detectAnomalies();var flagged=DB.observations.filter(function(o){return !o.retracted&&o.flags&&o.flags.length&&daysBetween(o.date,asOf())<=14;}).length;
    streams.consistency={level:an.length>2||flagged>3?'low':(an.length||flagged?'moderate':'high'),detail:(an.length?an.length+' anomal'+(an.length===1?'y':'ies'):'no anomalies')+(flagged?(' \u00b7 '+flagged+' flagged entries'):'')};
    var core=['weight','nutrition','activity','sleep','training'].map(function(k){return streams[k].level;});
    var score=core.reduce(function(a,l){return a+(l==='high'?3:l==='moderate'?2:l==='low'?1:0);},0)/(core.length*3);
    if(streams.consistency.level==='low')score*=0.8;
    var overall=score>=0.8?'high':(score>=0.55?'moderate':(score>=0.25?'low':'insufficient'));
    Object.keys(streams).forEach(function(k){if(streams[k].level==='low'||streams[k].level==='insufficient')reasons.push(k+': '+streams[k].detail);});
    return {streams:streams,overall:{level:overall,pct:Math.round(score*100)},reasons:reasons,anomalies:an};
  });
}
/* ---- muscle retention risk ---- */
function muscleRetentionRisk(){
  var ph=activePhase();var st=strengthTrend(),ad=adherenceState(14),tr=weightTrend(14),rec=recoveryState(),ts=trainingState();
  var have=0,score=0,factors=[];
  if(st.status==='ok'){have++;if(st.overall==='declining'){score+=2;factors.push({text:'strength declining across tracked lifts',tone:'negative'});}else if(st.overall.indexOf('decline')>=0){score+=1;factors.push({text:'some lifts declining',tone:'attention'});}else factors.push({text:'strength '+st.overall,tone:'good'});}
  if(ad.protein){have++;if(ad.protein.pct<60){score+=2;factors.push({text:'protein target met on '+ad.protein.pct+'% of logged days',tone:'negative'});}else if(ad.protein.pct<85){score+=1;factors.push({text:'protein target met on '+ad.protein.pct+'% of days',tone:'attention'});}else factors.push({text:'protein adequate ('+ad.protein.pct+'% of days)',tone:'good'});}
  var early=ph&&ph.type==='cut'&&daysBetween(ph.startDate,asOf())<14;
  if(tr.status==='ok'){have++;var band=targetRate();var sysBand=band&&band.band?band.band:band;if(early){factors.push({text:'rate of loss not assessed in the first 14 days (water and glycogen leave first)',tone:'neutral'});}else if(sysBand&&tr.slopePerWeek<sysBand.lo*1.3){score+=2;factors.push({text:'rate of loss '+fmtRate(tr.slopePerWeek)+' is well past the '+fmtRateRange(sysBand.lo,sysBand.hi)+' band',tone:'negative'});}else if(sysBand&&tr.slopePerWeek<sysBand.lo){score+=1;factors.push({text:'rate of loss slightly faster than the band',tone:'attention'});}else factors.push({text:'rate of loss within band',tone:'good'});}
  if(rec.status==='ok'){have++;if(rec.level==='poor'){score+=2;factors.push({text:'recovery poor',tone:'negative'});}else if(rec.level==='strained'){score+=1;factors.push({text:'recovery strained',tone:'attention'});}else factors.push({text:'recovery '+rec.level,tone:'good'});}
  if(ts.planned){have++;if(ts.consistency==='low'){score+=2;factors.push({text:'resistance training '+ts.adherence+'% of plan',tone:'negative'});}else if(ts.consistency==='partial'){score+=1;factors.push({text:'training partially consistent',tone:'attention'});}else factors.push({text:'training consistent',tone:'good'});}
  if(!ph||ph.type!=='cut')return {status:'n/a',level:'not in a cut',factors:factors};
  if(have<2)return {status:'insufficient',level:'insufficient data',factors:factors,need:['strength history (4+ exposures per lift)','protein logging','recovery ratings']};
  var strong=factors.some(function(f){return f.tone==='negative';});
  var level=score>=4?'high':((score>=3||(score>=2&&strong))?'medium':'low');
  return {status:'ok',cls:'HEURISTIC',level:level,score:score,factors:factors,confidence:have>=4?'medium':'low',note:'an interpretation from proxies, not a measurement of muscle'};
}
/* ---- step baseline ---- */
function stepState(){
  var s7=seriesWindow('steps',7),s28=seriesWindow('steps',28);
  var base=s28.length>=10?median(s28.slice(0,Math.max(5,Math.floor(s28.length/2))).map(function(d){return d.value;})):null;
  var m7=s7.length?mean(s7.map(function(d){return d.value;})):null;
  var tr=s28.length>=10?theilSen(s28.map(function(d){return {x:d.x,y:d.value};})).slope:null;
  var comp=null;if(tr!=null&&base!=null&&m7!=null&&tr*28<-1500&&m7<base*0.85&&seriesWindow('cardio',14).length>=3)comp='steps averaging '+fmtNum(m7,0)+' vs a baseline of '+fmtNum(base,0)+' while cardio is logged: possible NEAT compensation';
  return {mean7:m7,n7:s7.length,baseline:base,trendPerDay:tr,target:(activePhase()||{}).stepTarget||null,last:s7.length?s7[s7.length-1]:null,compensation:comp};
}
/* ---- canonical state ---- */
function getCurrentState(){
  return memo('state',function(){
    var ph=activePhase();
    var st={asOf:asOf(),phase:ph,phaseWeek:phaseWeek(ph),profile:prof(),
      weight:currentWeight(),averages:weightAverages(),trend:weightTrend(14),trend28:weightTrend(28),waterNoise:waterNoise(),
      waist:latestObs('waist'),waistTrend:waistTrend(28),bodyComp:bodyComp(),fatVsOther:fatVsOther(),
      tdee:tdeeEstimate(),energy:energyBalance(),targetRate:targetRate(),goal:goalTrajectory(),
      nutrition:nutritionToday(),adherence:adherenceState(14),steps:stepState(),training:trainingState(),recovery:recoveryState(),appetite:appetiteState(),muscleRisk:muscleRetentionRisk(),
      trust:dataTrust(),missing:missingness(14),forecast7:weightForecast(7),forecast14:weightForecast(14),forecast28:weightForecast(28)};
    return st;
  });
}
function nutritionToday(){
  var day=asOf();var ph=activePhase()||{};
  var get=function(t){var s=dailySeries(t,day,1);return s.length&&s[0].date===day?s[0]:null;};
  var cal=get('calories'),pr=get('protein'),cb=get('carbs'),ft=get('fat'),fb=get('fiber'),wt=get('water');
  var c7=seriesWindow('calories',7),p7=seriesWindow('protein',7),c14=seriesWindow('calories',14);
  return {date:day,calories:cal?cal.value:null,protein:pr?pr.value:null,carbs:cb?cb.value:null,fat:ft?ft.value:null,fiber:fb?fb.value:null,water:wt?wt.value:null,
    calorieTarget:ph.calorieTarget||null,proteinTarget:ph.proteinTarget||null,fiberTarget:ph.fiberTarget||null,fatFloor:ph.fatFloor||null,
    avg7:c7.length?mean(c7.map(function(d){return d.value;})):null,n7:c7.length,avg14:c14.length?mean(c14.map(function(d){return d.value;})):null,n14:c14.length,protein7:p7.length?mean(p7.map(function(d){return d.value;})):null,pn7:p7.length,
    fromFoodLog:!!(cal&&cal.obs.some(function(o){return o.source==='food-log';}))};
}
/* ---- protein target heuristic: anchored to target/lean weight during a cut ---- */
function proteinTargetSuggestion(){
  var p=prof();var w=weightAverages().avg7||currentWeight().value||p.startWeightLb;var goal=p.goalWeightLb;
  if(!w)return null;var anchor=goal&&goal<w?goal:w;var kg=lbToKg(anchor);
  return {lo:Math.round(kg*1.6),hi:Math.round(kg*2.2),anchorLb:anchor,basis:goal&&goal<w?'goal weight (avoids scaling protein to a large body mass)':'current weight',cls:'PRIOR',source:'ISSN 1.4\u20132.0 g/kg; Morton 2018 plateau ~1.6 g/kg; higher end during deficits'};
}
function calorieTargetSuggestion(){
  var t=tdeeEstimate();var band=targetRate();if(t.status!=='ok'||!band)return null;
  var zone=band.band||band;var midRate=(zone.lo+zone.hi)/2; // lb/week, negative for loss; zone band, not the user's stricter target
  var deficit=-midRate*TISSUE_KCAL_PER_LB/7;var cap=t.value*0.25;var capped=false;
  if(deficit>cap){deficit=cap;capped=true;}
  var b=bmrPrior();var floor=Math.max(b.status==='ok'?b.bmr:0,prof().sex==='female'?1200:1500);var floored=false;
  var target=roundTo(t.value-deficit,10);if(target<floor){target=roundTo(floor,10);floored=true;}
  return {value:target,lo:roundTo(Math.max(floor,t.lo-deficit),10),hi:roundTo(t.hi-deficit,10),tdee:t,deficit:round(t.value-target,0),rate:-(t.value-target)*7/TISSUE_KCAL_PER_LB,capped:capped,floored:floored,cls:t.cls==='PRIOR'?'PRIOR':'DERIVED',basis:'estimated TDEE minus the deficit for the middle of the zone band'+(capped?', capped at 25% of TDEE':'')+(floored?', floored at estimated BMR':'')};
}
