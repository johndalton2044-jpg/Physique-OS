/* ============================================================================
   REGION: SELF-TEST — runs inside the app (Tools) and headlessly (tests/run.mjs). Each check is an
   assertion about behavior the specification requires. A failing check is a build failure.
   ============================================================================ */
function runSelfTest(opts){
  opts=opts||{};var t0=Date.now();var results=[];var ok=function(name,cond,detail){results.push({name:name,ok:!!cond,detail:detail||''});};
  var savedDB=DB,savedNow=_NOW_OVERRIDE,savedMemo=_MEMO;
  var quiet=function(fn){var prevSave=save;save=function(){DB.ledger.saves++;};try{return fn();}finally{save=prevSave;}};
  try{
    quiet(function(){
    /* schema + storage */
    var e=emptyDB();ok('empty record validates',validateDB(e).ok,'schema '+SCHEMA_VERSION);
    var bad=validateDB({schemaVersion:1,observations:'nope'});ok('validateDB rejects corrupt input',!bad.ok,(bad.errors||[]).join('; '));
    var old={schemaVersion:0,observations:[],profile:{}};var m=migrate(JSON.parse(JSON.stringify(old)));ok('migration brings schema 0 to current',m.db.schemaVersion===SCHEMA_VERSION&&Array.isArray(m.db.predictions),'applied '+JSON.stringify(m.applied));
    var s=JSON.parse(serializeDB());ok('persistence round-trip keeps structure',s.schemaVersion===DB.schemaVersion&&Array.isArray(s.observations));
    /* observations */
    DB=emptyDB();_memoInvalidate();
    var o1=addObservation({type:'weight',date:todayISO(),value:250},{noSave:true,silent:true});
    var o2=correctObservation(o1.id,251,'test');
    ok('correction supersedes without rewriting',o1.value===250&&o1.correctedBy===o2.id&&o2.supersedes===o1.id&&obsOf('weight').length===1&&obsOf('weight')[0].value===251);
    retractObservation(o2.id,'test');ok('retraction excludes from reads but keeps the record',obsOf('weight').length===0&&DB.observations.length===2);
    var thrown=false;try{addObservation({type:'nope',value:1},{noSave:true,silent:true});}catch(x){thrown=true;}ok('unknown observation type is rejected',thrown);
    DB=emptyDB();_memoInvalidate();var d=todayISO();
    addObservation({type:'calories',date:d,value:1000,source:'food-log'},{noSave:true,silent:true});addObservation({type:'calories',date:d,value:1200,source:'food-log'},{noSave:true,silent:true});
    ok('daily series sums intake streams',dailySeries('calories',d,1)[0].value===2200);
    addObservation({type:'calories',date:d,value:2500,source:'manual'},{noSave:true,silent:true});
    ok('manual entry overrides food-log for the day (no double count)',dailySeries('calories',d,1)[0].value===2500);
    addObservation({type:'weight',date:d,value:200},{noSave:true,silent:true});addObservation({type:'weight',date:d,value:202},{noSave:true,silent:true});
    ok('daily series averages measurement streams',dailySeries('weight',d,1)[0].value===201);
    /* undo */
    DB=emptyDB();_memoInvalidate();_undoStack=[];addObservation({type:'weight',date:d,value:200},{noSave:true});ok('undo restores the previous record',canUndo()&&undo()&&DB.observations.length===0);
    /* stats */
    ok('median',median([3,1,2])===2);ok('theil-sen slope on a line',Math.abs(theilSen([{x:0,y:0},{x:1,y:2},{x:2,y:4},{x:3,y:6}]).slope-2)<1e-9);
    ok('ols residual sd on exact line is ~0',ols([{x:0,y:1},{x:1,y:3},{x:2,y:5}]).residSd<1e-9);
    ok('correlation of identical series is 1',Math.abs(correlation([1,2,3,4],[2,4,6,8]).r-1)<1e-9);
    /* models */
    var e1=e1rm(200,5);ok('e1RM consensus near Epley for 200x5',e1&&Math.abs(e1.value-233)<8,fmtNum(e1&&e1.value,1));
    ok('e1RM at 1 rep is measured',e1rm(300,1).reliability==='measured');
    DB=emptyDB();DB.profile={age:24,sex:'male',heightIn:72,startWeightLb:270,activityBaseline:'light'};_memoInvalidate();
    var pr=tdeePrior();ok('Mifflin-St Jeor prior for the demo profile is plausible',pr.status==='ok'&&pr.value>3000&&pr.value<3600,fmtKcal(pr.value));
    ok('rate band by weight zone',rateBand(270,'cut').lo===-2.5&&rateBand(200,'cut').hi===-0.75);
    ok('MET energy is derived and nonzero',Math.abs(metKcal(3.8,30,100)-199.5)<0.01);
    /* fixtures: decisions */
    var expect={normal_loss:['HOLD'],rapid_water:['HOLD'],stall:['ADD_STEPS','WAIT'],inconsistent:['INSUFFICIENT','ADHERENCE'],reduced_neat:['ADD_STEPS'],excessive:['REDUCE_DEFICIT'],strength_decline:['DELOAD','REDUCE_DEFICIT'],successful_cut:['HOLD'],maintenance:['HOLD'],regain:['TRIM'],insufficient:['INSUFFICIENT'],calibration:['HOLD'],failed_intervention:['REDUCE_CALORIES','WAIT'],successful_intervention:['HOLD']};
    Object.keys(expect).forEach(function(name){try{withFixture(name,function(db){var dec=decide();var S=getCurrentState();ok('fixture '+name+' \u2192 '+expect[name].join('|'),expect[name].indexOf(dec.code)>=0,dec.code+' \u00b7 trend '+(S.trend.status==='ok'?fmtRate(S.trend.slopePerWeek):'insufficient')+' \u00b7 '+dec.confidence);
        if(name==='rapid_water')ok('rapid water loss is not called fat loss',S.fatVsOther.status!=='ok'&&S.waterNoise.level!=='low',S.waterNoise.level);
        if(name==='insufficient')ok('insufficient data never produces a number for TDEE personal',S.tdee.cls==='PRIOR'&&S.trend.status==='insufficient');
        if(name==='maintenance')ok('maintenance: stable weight is not called fat gain',S.trend.direction==='flat'&&dec.code==='HOLD');
        if(name==='excessive')ok('excessive deficit is flagged as too fast',diagnose().findings.some(function(f){return f.id==='rapid';}));
        if(name==='stall')ok('genuine stall diagnosed',diagnose().primary.id==='stall');
        if(name==='calibration'){var acc=forecastAccuracy();ok('prediction calibration: 14-day forecasts scored',acc.weight14.status==='ok'&&acc.weight14.n>=3,'n='+acc.weight14.n+' mae='+(acc.weight14.mae!=null?fmtNum(acc.weight14.mae,2):'?'));ok('TDEE reaches EMPIRICAL or CALIBRATED with 60 days of data',S.tdee.cls==='EMPIRICAL'||S.tdee.cls==='CALIBRATED',S.tdee.cls);}
        if(name==='failed_intervention'){var negs=getNegativeKnowledge();ok('failed intervention becomes negative knowledge',negs.length>=1&&negs[0].variable==='steps');ok('negative knowledge influences the next decision',dec.code!=='ADD_STEPS');}
        if(name==='successful_intervention')ok('successful intervention scored as supported',db.experiments.some(function(x){return x.conclusion==='supported';}));
        if(name==='strength_decline')ok('strength decline detected',S.training.strength.status==='ok'&&S.training.strength.overall==='declining');
      });}catch(x){ok('fixture '+name+' runs',false,x.message);}});
    /* epistemic rules */
    withFixture('successful_cut',function(){var S=getCurrentState();ok('weight is MEASURED, trend is DERIVED, TDEE personal is EMPIRICAL/BLENDED, forecast is PREDICTIVE',S.weight.obs.quality==='demo'&&/EMPIRICAL|BLENDED|CALIBRATED/.test(S.tdee.cls)&&S.forecast14.cls==='PREDICTIVE'&&S.bodyComp.estimate.cls==='HEURISTIC',S.tdee.cls);
      var html=uiMetric({label:'x',value:'1',cls:'PREDICTIVE'});ok('predictive values render in the inferred style',/class="metric inferred"/.test(html));
      var html2=uiMetric({label:'x',value:'1',cls:'MEASURED'});ok('measured values never render as inferred',!/inferred/.test(html2));
      ok('every model has class, version, inputs, assumptions and failure modes',MODELS.every(function(mm){return mm.cls&&mm.version&&mm.inputs.length&&mm.assumes.length&&mm.failsWhen.length;}));
      var dec=decide();ok('decision carries decision/why/action/confidence/recheck/reverse-if/trace',dec.verb&&dec.lede&&Array.isArray(dec.why)&&Array.isArray(dec.action)&&dec.confidence&&dec.trace&&Array.isArray(dec.reverseIf));
      ok('provenance and age are attached to the weight tile',/age-(fresh|aging|stale)/.test(uiMetric({label:'w',value:'1',cls:'MEASURED',date:todayISO(),type:'weight'})));
      /* prediction ledger */
      var made=stampPredictions();ok('predictions are stamped with model version and inputs before outcomes',made.length>=1&&made[0].modelVersion&&made[0].inputs&&made[0].status==='pending'&&made[0].actual===null);
      var frozen=JSON.stringify(made[0]);scorePredictions();ok('pending prediction is not modified before its due date',JSON.stringify(DB.predictions.filter(function(p){return p.id===made[0].id;})[0])===frozen);
      /* replay leakage */
      var dates=[addDays(todayISO(),-30),addDays(todayISO(),-14),addDays(todayISO(),-3)];var leaks=replayLeakageCheck(dates);ok('replay never reads future observations',leaks.length===0,leaks.length+' leaks');
      var r=replayAt(addDays(todayISO(),-21));ok('replay produces a decision from past-only data',r.decision&&r.decision.code&&r.state.asOf===addDays(todayISO(),-21));
      /* counterfactual does not mutate */
      var before=JSON.stringify(DB.observations.length+':'+DB.decisions.length+':'+DB.predictions.length);var exps=DB.experiments.length;withAsOf(addDays(todayISO(),-10),function(){decide();diagnose();});ok('replay/counterfactual does not mutate the record',before===JSON.stringify(DB.observations.length+':'+DB.decisions.length+':'+DB.predictions.length)&&DB.experiments.length===exps);
      /* hold steady on stable data */
      ok('hold steady is produced on good data',dec.code==='HOLD');
      /* snapshots + archive */
      var snap=captureSnapshot();ok('snapshot captured with decision and trust',snap.decision&&snap.trust&&snap.date===todayISO());
      var ph=activePhase();var summ=archivePhase(ph);ok('phase archive summary computed with model versions',summ.startWeight!=null&&DB.archive.length>=1&&DB.archive[DB.archive.length-1].record.modelVersions.length===MODELS.length);
    });
    /* negative knowledge persistence + influence */
    withFixture('stall',function(){createExperiment({question:'t',variable:'steps',baselineValue:7000,interventionValue:9000,prediction:'x',predLo:-0.4,predHi:-0.2,durationDays:14,silent:true,noSave:true});_memoInvalidate();var d2=decide();ok('an active experiment holds lower-priority levels (attributability)',d2.code==='EXPERIMENT',d2.code);DB.experiments=[];DB.interventions=[];_memoInvalidate();addNegative({intervention:'+2000 steps',variable:'steps',expected:'-0.3 lb/wk',observed:'no change',reasons:['compensation'],confidence:'medium',silent:true});_memoInvalidate();var dec=decide();ok('negative knowledge for steps redirects the plateau decision',dec.code==='REDUCE_CALORIES',dec.code);});
    /* food */
    DB=emptyDB();_memoInvalidate();
    var seed=foodSearchLocal('chicken breast',3);ok('foundation search finds chicken',seed.length>0&&/chicken/i.test(seed[0].name),seed[0]&&seed[0].name);
    if(seed.length){var g=portionGrams(seed[0],150,'g');var n=nutrientsFor(seed[0],g);ok('nutrients scale linearly from per-100 g',n.kcal!=null&&Math.abs(n.kcal-seed[0].per100g.kcal*1.5)<0.2);var fl=logFood({date:d,meal:'lunch',food:seed[0],grams:150,silent:true,noSave:true});ok('food log creates derived nutrition observations',obsOf('calories').length===1&&obsOf('calories')[0].source==='food-log'&&fl.food.version===FOUNDATION_RELEASE);
      var snapBefore=JSON.stringify(fl.food.per100g);seed[0].per100g.kcal=9999;ok('logged item keeps its nutrient snapshot when the source changes',JSON.stringify(fl.food.per100g)===snapBefore);seed[0].per100g.kcal=JSON.parse(snapBefore).kcal;_memoInvalidate();
      removeFoodLog(fl.id);ok('removing the item retracts its derived observations',obsOf('calories').length===0);}
    var rcp={name:'t',servings:2,ingredients:[{food:seed[0],grams:200}]};var tot=recipeTotals(rcp);ok('recipe per-serving divides totals',Math.abs(tot.perServing.kcal*2-tot.totals.kcal)<0.01);
    ok('portion units resolve to grams',portionGrams({portions:[]},2,'oz')>56&&portionGrams({portions:[{label:'1 cup',g:240}]},1,'portion:1 cup')===240);
    ok('branded record decoder shape',typeof brandedToFood==='function'&&FOOD_SOURCES.length>=3);
    /* exercise ontology */
    ok('exercise resolution and substitution',resolveExercise('Squat or leg press')&&substitutesFor('bench press').length>0);
    /* reference data */
    ok('reference knowledge carries source and date',REF_DGA.published&&REF_SUPPLEMENTS.published&&REF_COMPENDIUM_INLINE.activities.length>30&&REF_EVIDENCE.every(function(x){return x.citation;}));
    /* demo */
    var prevDB=DB;var gen=generateRecord(DEMO_SPEC,11);ok('demo generator is deterministic',JSON.stringify(generateRecord(DEMO_SPEC,11).db.observations.slice(0,20).map(function(x){return x.value;}))===JSON.stringify(gen.db.observations.slice(0,20).map(function(x){return x.value;})));
    ok('demo data is marked demo everywhere',gen.db.demo.active&&gen.db.observations.every(function(x){return x.source==='demo';}));DB=prevDB;
    /* UI wiring (DOM only) */
    if(typeof document!=='undefined'&&document.getElementById('decisionZone')){
      var missing=[];Array.prototype.slice.call(document.querySelectorAll('[data-act]')).forEach(function(el){var a=el.getAttribute('data-act');if(!ACTIONS[a]&&missing.indexOf(a)<0)missing.push(a);});ok('every data-act in the document resolves to a registered action',missing.length===0,missing.join(', '));
      var errsBefore=getSwallowedErrors().count;var prevTab=_TAB;var prevDB2=DB;DB=FIXTURES.successful_cut();_memoInvalidate();
      Object.keys(RENDERERS).forEach(function(tab){try{_TAB=tab;RENDERERS[tab]();}catch(x){ok('view '+tab+' renders',false,x.message);}});
      var errsAfter=getSwallowedErrors().count;ok('all 12 views render without quarantined errors',errsAfter===errsBefore&&Object.keys(RENDERERS).length===12,'errors '+(errsAfter-errsBefore));
      DB=emptyDB();_memoInvalidate();Object.keys(RENDERERS).forEach(function(tab){try{_TAB=tab;RENDERERS[tab]();}catch(x){ok('empty view '+tab+' renders',false,x.message);}});ok('all views render on an empty record',getSwallowedErrors().count===errsAfter);
      DB=prevDB2;_TAB=prevTab;_memoInvalidate();
      makeDelegatedControlsFocusable();var acts=Array.prototype.slice.call(document.querySelectorAll('[data-act]')).filter(function(el){var t=el.tagName;var role=el.getAttribute('role');return !(t==='BUTTON'||t==='A'||t==='INPUT'||t==='SELECT'||t==='TEXTAREA'||t==='SUMMARY'||role==='presentation'||role==='option')&&el.getAttribute('tabindex')!=='0';});ok('non-button data-act controls are keyboard focusable',acts.length===0,acts.length+' unfocusable');
      var cmdMissing=COMMANDS.filter(function(c){return typeof c.run!=='function';});ok('every command is runnable',cmdMissing.length===0&&COMMANDS.length>=30,COMMANDS.length+' commands');
      var au=runA11yAudit();ok('a11y audit: no unnamed controls or unlabeled dialogs',!au.issues.some(function(i){return i.kind==='unnamed control'||i.kind==='dialog without label';}),au.issues.map(function(i){return i.kind+':'+i.el;}).slice(0,4).join('; '));
    }
    /* exports */
    withFixture('successful_cut',function(){var csv=exportCSV('weight');ok('CSV export has header and rows',csv.split('\n').length>10&&/^date,weight_lb/.test(csv));var rep=stateReport();ok('state report contains decision and learning sections',/DECISION:/.test(rep)&&/WHAT WE KNOW/.test(rep));var b=JSON.parse(backupJSON());ok('backup JSON carries schema/app/counts',b.backup&&b.backup.schemaVersion===SCHEMA_VERSION&&b.backup.counts.observations>0);var ics=icsExport();ok('ICS export is well-formed',/BEGIN:VCALENDAR/.test(ics)&&/END:VCALENDAR/.test(ics));});
    });
  }catch(err){results.push({name:'self-test harness',ok:false,detail:err.message+' '+(err.stack||'').split('\n')[1]});}
  finally{DB=savedDB;_NOW_OVERRIDE=savedNow;_MEMO=savedMemo;_memoInvalidate();}
  var passed=results.filter(function(r){return r.ok;}).length,failed=results.length-passed;
  return {passed:passed,failed:failed,results:results,ms:Date.now()-t0,at:nowISO()};
}
