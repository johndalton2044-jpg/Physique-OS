/* ============================================================================
   REGION: UI PRIMITIVES — state is the truth, the DOM is a render target. Every number carries its
   epistemic class, provenance and age. Folds carry a signal in their summary.
   ============================================================================ */
var _TAB='today';
function h(strings){var out='';for(var i=0;i<strings.length;i++){out+=strings[i];if(i<arguments.length-1){var v=arguments[i+1];out+=(v==null?'':v);}}return out;}
function uiCard(o){o=o||{};return '<div class="card'+(o.accent?' accent-'+o.accent:'')+(o.cls?' '+o.cls:'')+'"'+(o.id?' id="'+o.id+'"':'')+'>'+(o.title?'<div class="card-head"><div class="card-title">'+o.title+'</div>'+(o.sub?'<div class="card-sub">'+o.sub+'</div>':'')+'</div>':'')+(o.body||'')+'</div>';}
function uiRow(l,r,o){o=o||{};return '<div class="row'+(o.tight?' tight':'')+'"><div class="l">'+l+(o.sub?'<small>'+o.sub+'</small>':'')+'</div><div class="r'+(o.tone?' '+o.tone:'')+'">'+r+(o.rsub?'<small>'+o.rsub+'</small>':'')+'</div></div>';}
function uiPill(text,tone){return '<span class="pill'+(tone?' '+tone:'')+'">'+text+'</span>';}
function clsMark(cls){if(!cls)return '';var c=String(cls).toLowerCase();var short={measured:'MEASURED',derived:'DERIVED',heuristic:'HEURISTIC',prior:'PRIOR',empirical:'EMPIRICAL',calibrated:'CALIBRATED',predictive:'PREDICTIVE',blended:'PRIOR+EMPIRICAL',reference:'REFERENCE',inferred:'INFERRED','empirical-population':'POPULATION'};return '<span class="cls-mark '+c.replace(/[^a-z]/g,'')+'" title="'+attrEsc(CLASSES[cls.toUpperCase()]||'')+'">'+(short[c]||c.toUpperCase())+'</span>';}
function ageSpan(iso){if(!iso)return '<span class="age-stale">undated</span>';var f=freshness('generic',iso);return '<span class="age-'+f.state+'">'+ageLabel(iso)+'</span>';}
function uiProv(parts){return '<div class="prov">'+parts.filter(Boolean).join(' \u00b7 ')+'</div>';}
/* metric tile: label, value, unit, class, source, age; empty tiles say what is missing */
function uiMetric(o){
  if(o.value==null||o.value==='\u2014')return '<div class="metric empty'+(o.cls?' '+o.cls:'')+'"><div class="m-label"><span>'+o.label+'</span></div><div class="m-value">'+(o.emptyText||'no data')+'</div><div class="m-prov">'+(o.need||'')+'</div></div>';
  var inferred=/predict|heuristic|prior|empirical|calibrated|blended/i.test(o.cls||'');
  var stale=o.date&&freshness(o.type||'generic',o.date).state==='stale';
  return '<div class="metric'+(inferred?' inferred':'')+(stale?' stale':'')+'"><div class="m-label"><span>'+o.label+'</span>'+(o.badge?'<span>'+o.badge+'</span>':'')+'</div><div class="m-value">'+o.value+(o.unit?'<span class="unit">'+o.unit+'</span>':'')+'</div><div class="m-prov">'+[o.cls?'<span class="cls '+String(o.cls).toLowerCase().replace(/[^a-z]/g,'')+'">'+String(o.cls).toUpperCase().replace('BLENDED','PRIOR+EMP')+'</span>':'',o.source||'',o.date?'<span class="age-'+freshness(o.type||'generic',o.date).state+'">'+ageLabel(o.date)+'</span>':'',o.conf?('conf '+o.conf):''].filter(Boolean).join(' \u00b7 ')+'</div></div>';
}
function uiFold(id,title,signal,body,opts){opts=opts||{};var open=DB.settings.folds&&DB.settings.folds[id]!=null?!!DB.settings.folds[id]:!!opts.open;return '<details class="fold'+(opts.urgent?' urgent':'')+'" data-fold="'+id+'"'+(open?' open':'')+'><summary data-act="ui.fold" data-arg="'+id+'"><span class="f-title">'+title+'</span><span class="f-signal'+(opts.tone?' '+opts.tone:'')+'">'+(signal||'')+'</span><span class="f-chev">\u203a</span></summary><div class="f-body">'+body+'</div></details>';}
function uiEmpty(title,body,btn){return '<div class="empty"><b>'+title+'</b>'+body+(btn?'<div>'+btn+'</div>':'')+'</div>';}
function uiBtn(label,act,arg,cls,extra){return '<button class="btn '+(cls||'btn-secondary')+'" data-act="'+act+'"'+(arg!=null?' data-arg="'+attrEsc(String(arg))+'"':'')+(extra||'')+'>'+label+'</button>';}
function confPill(c){return uiPill('conf '+(c||'\u2014'),confTone(c));}
function tonePill(level,map){var t=(map||{})[level]||'neutral';return uiPill(level,t);}
function sectionH(title,count){return '<h3 class="section-h">'+title+(count!=null?'<span class="count">'+count+'</span>':'')+'</h3>';}
function progressBar(pct,tone){return '<div class="progress-bar"><i class="'+(tone||'')+'" style="width:'+clamp(pct||0,0,100)+'%"></i></div>';}
function kv(pairs){return '<dl class="kv">'+pairs.map(function(p){return '<dt>'+p[0]+'</dt><dd>'+p[1]+'</dd>';}).join('')+'</dl>';}
/* ---- SVG chart: observed dots, averaged line, trend dashed, predicted dotted + band; grid + axes ---- */
function svgChart(o){
  var W=o.width||640,H=o.height||200,pl=46,pr=12,pt=12,pb=22;
  var series=(o.series||[]).filter(function(s){return s&&s.pts&&s.pts.length;});
  var xs=[],ys=[];series.forEach(function(s){s.pts.forEach(function(p){if(p.x!=null)xs.push(p.x);if(p.y!=null)ys.push(p.y);if(p.lo!=null)ys.push(p.lo);if(p.hi!=null)ys.push(p.hi);});});
  if(o.yLines)o.yLines.forEach(function(l){ys.push(l.y);});
  if(!xs.length||!ys.length)return '<div class="empty">'+(o.emptyText||'Not enough observations to draw yet.')+'</div>';
  var xmin=Math.min.apply(null,xs),xmax=Math.max.apply(null,xs);if(xmax===xmin)xmax=xmin+1;
  var ymin=Math.min.apply(null,ys),ymax=Math.max.apply(null,ys);var pad=(ymax-ymin)*0.12||1;ymin-=pad;ymax+=pad;if(o.yMin!=null)ymin=Math.min(ymin,o.yMin);if(o.zeroBase)ymin=0;
  var X=function(x){return pl+(x-xmin)/(xmax-xmin)*(W-pl-pr);},Y=function(y){return pt+(1-(y-ymin)/(ymax-ymin))*(H-pt-pb);};
  var out='<svg class="chart" viewBox="0 0 '+W+' '+H+'" role="img" aria-label="'+attrEsc(o.aria||o.title||'chart')+'" preserveAspectRatio="none" style="aspect-ratio:'+W+'/'+H+'">';
  var ticks=4;for(var i=0;i<=ticks;i++){var yv=ymin+(ymax-ymin)*i/ticks;out+='<line class="grid" x1="'+pl+'" x2="'+(W-pr)+'" y1="'+Y(yv).toFixed(1)+'" y2="'+Y(yv).toFixed(1)+'"/><text class="axis" x="'+(pl-6)+'" y="'+(Y(yv)+3).toFixed(1)+'" text-anchor="end">'+(o.yFmt?o.yFmt(yv):fmtNum(yv,0))+'</text>';}
  (o.xLabels||[]).forEach(function(l){out+='<text class="axis" x="'+X(l.x).toFixed(1)+'" y="'+(H-6)+'" text-anchor="middle">'+esc(l.label)+'</text>';});
  (o.yLines||[]).forEach(function(l){out+='<line class="'+(l.cls||'target')+'" x1="'+pl+'" x2="'+(W-pr)+'" y1="'+Y(l.y).toFixed(1)+'" y2="'+Y(l.y).toFixed(1)+'"/>';});
  (o.xMarkers||[]).forEach(function(m){out+='<line class="marker" x1="'+X(m.x).toFixed(1)+'" x2="'+X(m.x).toFixed(1)+'" y1="'+pt+'" y2="'+(H-pb)+'"/>'+(m.label?'<text class="axis" x="'+(X(m.x)+3).toFixed(1)+'" y="'+(pt+9)+'">'+esc(m.label)+'</text>':'');});
  series.forEach(function(s){
    if(s.type==='band'){var up=s.pts.filter(function(p){return p.hi!=null;}).map(function(p){return X(p.x).toFixed(1)+','+Y(p.hi).toFixed(1);});var lo=s.pts.filter(function(p){return p.lo!=null;}).map(function(p){return X(p.x).toFixed(1)+','+Y(p.lo).toFixed(1);}).reverse();if(up.length&&lo.length)out+='<polygon class="band" points="'+up.concat(lo).join(' ')+'"/>';}
    else if(s.type==='bars'){var bw=Math.max(2,(W-pl-pr)/Math.max(1,(xmax-xmin+1))*0.7);s.pts.forEach(function(p){if(p.y==null)return;var y=Y(p.y),y0=Y(Math.max(ymin,0));out+='<rect class="bar'+(p.cls?' '+p.cls:'')+'" x="'+(X(p.x)-bw/2).toFixed(1)+'" y="'+Math.min(y,y0).toFixed(1)+'" width="'+bw.toFixed(1)+'" height="'+Math.abs(y0-y).toFixed(1)+'"/>';});}
    else if(s.type==='dots'){s.pts.forEach(function(p){if(p.y==null)return;out+='<circle class="obs'+(p.cls?' '+p.cls:'')+'" cx="'+X(p.x).toFixed(1)+'" cy="'+Y(p.y).toFixed(1)+'" r="'+(s.r||2.4)+'"/>';});}
    else{var d='';s.pts.forEach(function(p,i){if(p.y==null){d+='';return;}d+=(i===0||!s.pts[i-1]||s.pts[i-1].y==null?'M':'L')+X(p.x).toFixed(1)+' '+Y(p.y).toFixed(1)+' ';});out+='<path class="'+(s.cls||'avg')+'" d="'+d.trim()+'"/>';}
  });
  return out+'</svg>';
}
function chartLegend(items){return '<div class="legend">'+items.map(function(i){return '<span class="lg-'+i[0]+'">'+i[1]+'</span>';}).join('')+'</div>';}
function xLabelsFor(dates,n){var out=[];if(!dates.length)return out;var step=Math.max(1,Math.floor(dates.length/(n||5)));for(var i=0;i<dates.length;i+=step)out.push({x:dates[i].x,label:shortDate(dates[i].date)});return out;}
/* ---- toast / announce ---- */
var _toastT=null;
function toast(msg,opts){opts=opts||{};var t=document.getElementById('toast');if(!t)return;t.innerHTML=msg+(opts.undo?' <button class="link" data-act="undo.last">Undo</button>':'');t.className='toast show'+(opts.tone?' '+opts.tone:'');clearTimeout(_toastT);_toastT=setTimeout(function(){t.className='toast';},opts.ms||3200);announce(msg.replace(/<[^>]+>/g,''));}
function announce(text){var a=document.getElementById('a11yAnnouncer');if(a){a.textContent='';setTimeout(function(){a.textContent=text;},30);}}
function setHTML(id,html){var el=document.getElementById(id);if(el)el.innerHTML=html;}
