import fs from 'node:fs';import {JSDOM,VirtualConsole} from 'jsdom';
const html=fs.readFileSync('dist/index.html','utf8');const vc=new VirtualConsole();
const dom=new JSDOM(html,{url:'https://physique.local/app/index.html',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(w){w.matchMedia=()=>({matches:false,addEventListener(){}});w.scrollTo=()=>{};w.HTMLElement.prototype.scrollIntoView=function(){};w.fetch=undefined;}});
const w=dom.window;await new Promise(r=>setTimeout(r,300));
const text=(el)=>el.textContent.replace(/\s+/g,' ').trim();
console.log(text(w.document.getElementById('view-today')).slice(0,1500));
// after profile + phase but no data
w.DB.profile={name:'ZF',age:24,sex:'male',heightIn:72,startWeightLb:270,goalWeightLb:180,activityBaseline:'light',sleepTargetH:7.5};w.startPhase({type:'cut',calorieTarget:2400,proteinTarget:195,stepTarget:8000,trainingSessions:3,cardioSessions:2,cardioMinutes:30,sleepTargetH:7.5,goalWeightLb:180});w._memoInvalidate();w.switchTab('today');
console.log('\n--- with phase, no observations ---\n'+text(w.document.getElementById('view-today')).slice(0,1400));
