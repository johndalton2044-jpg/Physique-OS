import fs from 'node:fs';import vm from 'node:vm';
const files=['10-core.js','20-schema-storage.js','30-observations.js','40-models.js','50-decision.js','60-data-foundation.js','62-food.js','64-exercise.js','66-data-reference.js','70-demo.js'];
let code=files.map(f=>fs.readFileSync('src/'+f,'utf8')).join('\n');
const store={};const ctx={console,localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=String(v);},removeItem:k=>{delete store[k];}},setTimeout,clearTimeout,Date,Math,JSON,navigator:{onLine:true},performance};ctx.globalThis=ctx;ctx.window=ctx;vm.createContext(ctx);vm.runInContext(code,ctx);
vm.runInContext(`
DB=emptyDB();
console.log('swallowed shape:',typeof getSwallowedErrors(), JSON.stringify(getSwallowedErrors()).slice(0,200));
withFixture('normal_loss',function(){var S=getCurrentState();console.log('normal protein adh',JSON.stringify(S.adherence.protein),'training',JSON.stringify(S.adherence.training),'muscle',JSON.stringify(S.muscleRisk.factors),S.muscleRisk.level,'band',JSON.stringify(S.targetRate&&{lo:S.targetRate.lo,hi:S.targetRate.hi}));});
withFixture('strength_decline',function(){var S=getCurrentState();var st=S.training.strength;console.log('strength_decline',st.overall,st.maxConsecutiveDeclines,st.per.map(function(p){return p.exercise+':'+p.direction+':'+(p.history||[]).map(function(h){return Math.round(h.best.value);}).join(',');}).join(' | '));});
withFixture('successful_intervention',function(){var S=getCurrentState();console.log('succ band',JSON.stringify({lo:S.targetRate.lo,hi:S.targetRate.hi,src:S.targetRate.source}),'avg7',S.averages.avg7,'trend',S.trend.slopePerWeek,'diag',diagnose().findings.map(function(f){return f.id+'/'+f.likelihood;}).join(','));});
withFixture('stall',function(){var S=getCurrentState();console.log('stall trend14',S.trend.slopePerWeek,S.trend.span,'trend28',S.trend28.status,S.trend28.slopePerWeek,S.trend28.span,S.trend28.direction);});
withFixture('rapid_water',function(){var S=getCurrentState();console.log('rapid muscle',S.muscleRisk.level,JSON.stringify(S.muscleRisk.factors.map(function(f){return f.text;})));});
`,ctx);
