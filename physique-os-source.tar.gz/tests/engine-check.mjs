// Headless engine harness: loads the JS layers (no DOM) and exercises fixtures.
import fs from 'node:fs';import vm from 'node:vm';
const files=['10-core.js','20-schema-storage.js','30-observations.js','40-models.js','50-decision.js','60-data-foundation.js','62-food.js','64-exercise.js','66-data-reference.js','70-demo.js'];
let code=files.map(f=>fs.readFileSync('src/'+f,'utf8')).join('\n');
const store={};const ctx={console,localStorage:{getItem:k=>store[k]??null,setItem:(k,v)=>{store[k]=String(v);},removeItem:k=>{delete store[k];},key:i=>Object.keys(store)[i]??null,get length(){return Object.keys(store).length;}},setTimeout,clearTimeout,Date,Math,JSON,fetch:undefined,navigator:{onLine:true},window:{addEventListener(){},},performance};
ctx.globalThis=ctx;ctx.window=ctx;
vm.createContext(ctx);
vm.runInContext(code,ctx,{filename:'engine.js'});
vm.runInContext(`
DB=emptyDB();
var out={};
Object.keys(FIXTURES).forEach(function(name){
  try{
    withFixture(name,function(db){
      var S=getCurrentState();var dec=decide();var d=diagnose();
      out[name]={decision:dec.code,conf:dec.confidence,trend:S.trend.status==='ok'?round(S.trend.slopePerWeek,2)+' ('+S.trend.confidence+')':S.trend.status+':'+(S.trend.need||[]).join('|'),tdee:S.tdee.status==='ok'?Math.round(S.tdee.value)+' '+S.tdee.cls:'insufficient',trust:S.trust.overall.level,diag:d.primary.id,recovery:S.recovery.level,strength:S.training.strength.status==='ok'?S.training.strength.overall:'insufficient',preds:(db.predictions||[]).length,scored:(db.predictions||[]).filter(function(p){return p.status==='scored';}).length,exps:(db.experiments||[]).map(function(e){return e.conclusion||e.status;}).join(','),negs:(db.negatives||[]).length,errors:getSwallowedErrors().length};
    });
  }catch(e){out[name]={error:e.message,stack:String(e.stack).split('\\n').slice(0,3).join(' | ')};}
});
console.log(JSON.stringify(out,null,1));
console.log('swallowed:',JSON.stringify(getSwallowedErrors().slice(0,5)));
`,ctx);
