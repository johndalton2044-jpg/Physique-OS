// Headless build gate for PHYSIQUE OS. Boots dist/index.html in jsdom, exercises views and sheets, runs the
// in-app self-test and the accessibility audit. Exits non-zero on any failure or quarantined runtime error.
import fs from 'node:fs';import {JSDOM,VirtualConsole} from 'jsdom';
const html=fs.readFileSync('dist/index.html','utf8');
const vc=new VirtualConsole();const consoleErrors=[];vc.on('jsdomError',e=>{consoleErrors.push(String(e&&e.message||e));});vc.on('error',m=>consoleErrors.push(String(m)));vc.on('warn',()=>{});vc.on('log',()=>{});
const dom=new JSDOM(html,{url:'https://physique.local/app/index.html',runScripts:'dangerously',pretendToBeVisual:true,virtualConsole:vc,beforeParse(window){window.matchMedia=window.matchMedia||(()=>({matches:false,addEventListener(){},removeEventListener(){}}));window.scrollTo=()=>{};window.requestAnimationFrame=f=>setTimeout(f,0);Object.defineProperty(window.navigator,'onLine',{value:true,configurable:true});window.fetch=undefined;window.HTMLElement.prototype.scrollIntoView=function(){};window.URL.createObjectURL=()=>'blob:x';window.URL.revokeObjectURL=()=>{};}});
const w=dom.window;
const sleep=ms=>new Promise(r=>setTimeout(r,ms));
let failures=0;const report=[];const ok=(name,cond,detail)=>{report.push((cond?'  pass  ':'  FAIL  ')+name+(detail?'  — '+detail:''));if(!cond)failures++;};
await sleep(300);
ok('boot completed',w._BOOTED===true&&w.DB&&typeof w.DB==='object');
ok('no jsdom runtime errors during boot',consoleErrors.length===0,consoleErrors.slice(0,3).join(' | '));
ok('no quarantined errors during boot',w.getSwallowedErrors().count===0,JSON.stringify(w.getSwallowedErrors().top.slice(0,3)));
/* load the demo and walk every view */
w.loadDemo();w.applySettings();w._memoInvalidate();
const tabs=['today','log','plan','train','food','body','progress','diagnose','experiments','learn','archive','tools'];
for(const t of tabs){const before=w.getSwallowedErrors().count;w.switchTab(t);await sleep(5);const zone=w.document.getElementById(t==='today'?'decisionZone':(t==='log'?'logListZone':t+'Zone'));ok('view '+t+' renders content',zone&&zone.innerHTML.length>200&&w.getSwallowedErrors().count===before,zone?zone.innerHTML.length+' chars':'no zone');}
/* decision content on the demo record */
w.switchTab('today');const dec=w.decide();ok('demo record produces a decision with trace',dec.code&&dec.trace&&dec.why.length>0,dec.code+' · '+dec.confidence+' · '+dec.lede.slice(0,90));
const S=w.getCurrentState();ok('demo TDEE is personalized',['EMPIRICAL','CALIBRATED','BLENDED'].includes(S.tdee.cls),S.tdee.cls+' '+Math.round(S.tdee.value));
ok('demo has scored predictions and a completed experiment',w.DB.predictions.filter(p=>p.status==='scored').length>=3&&w.DB.experiments.some(e=>e.status==='complete'),w.DB.predictions.length+' preds, '+w.DB.experiments.map(e=>e.conclusion||e.status).join(','));
ok('demo decision history recorded',w.DB.decisions.length>=4,w.DB.decisions.map(d=>d.code).join(','));
/* sheets */
const sheetTests=[['log weight',()=>w.openLog('weight')],['log food',()=>w.openLog('food')],['log cardio',()=>w.openLog('cardio')],['log sleep',()=>w.openLog('sleep')],['log recovery',()=>w.openLog('recovery')],['log hunger',()=>w.openLog('hunger')],['log waist',()=>w.openLog('waist')],['log bodyfat',()=>w.openLog('bodyfat')],['log context',()=>w.openLog('context')],['log note',()=>w.openLog('note')],['profile',()=>w.openProfile()],['phase edit',()=>w.openPhase(w.activePhase().id)],['phase new',()=>w.openPhase(null,'maintenance')],['session',()=>w.openSession(null)],['experiment',()=>w.openExperiment()],['food add',()=>w.openFoodAdd(w.todayISO())],['recipe',()=>w.openRecipe(null)],['custom food',()=>w.dispatchAct('food.custom','')],['negative',()=>w.dispatchAct('neg.new')],['user decision',()=>w.dispatchAct('decision.user')]];
for(const [name,fn] of sheetTests){const before=w.getSwallowedErrors().count;try{fn();await sleep(5);const open=w.document.querySelector('.sheet-backdrop.show');ok('sheet '+name+' opens and renders',open&&open.querySelector('.sheet-body').innerHTML.length>50&&w.getSwallowedErrors().count===before);w.closeSheet();}catch(e){ok('sheet '+name,false,e.message);}}
/* end-to-end interactions through the dispatcher */
const n0=w.DB.observations.length;const plausible=(w.getCurrentState().averages.avg7-0.4).toFixed(1);w.openLog('weight');w.setField('value',plausible);w.saveQuickLog(false);await sleep(5);ok('quick log saves a weight through the sheet',w.DB.observations.length===n0+1&&w.DB.observations[w.DB.observations.length-1].type==='weight');
w.dispatchAct('undo.last');ok('undo reverts the quick log',w.DB.observations.length===n0);
w.openLog('weight');w.setField('value','180');w.saveQuickLog(false);await sleep(5);ok('implausible jump asks before saving (flag/outlier gate)',w.DB.observations.length===n0&&w.document.getElementById('logFoot').textContent.includes('Save anyway'));w.closeSheet();
w.switchTab('food');const food=w.foodSearchLocal('banana',1)[0];const fl0=w.DB.foodLogs.length;w.logFood({date:w.todayISO(),meal:'snacks',food:food,grams:120});ok('food log adds an item and nutrition observations',w.DB.foodLogs.length===fl0+1&&w.obsOf('calories').some(o=>o.source==='food-log'&&o.date===w.todayISO()));
w.dispatchAct('food.search',null,null,{value:'greek yog'});await sleep(20);ok('food search renders local results without the branded shards',w.document.getElementById('foodResults').innerHTML.includes('food-item')&&w._FOOD_RESULTS.state!=='loading',w._FOOD_RESULTS.state);
w.switchTab('archive');w.document.getElementById('replayDate').value=w.addDays(w.todayISO(),-21);w.dispatchAct('replay.run');ok('replay renders a past decision',w._REPLAY&&w._REPLAY.decision.code&&w.document.getElementById('archiveZone').innerHTML.includes('Replayed decision'),w._REPLAY&&w._REPLAY.decision.code);
w.switchTab('diagnose');w.dispatchAct('diag.sym','stalled');ok('symptom picker produces hypotheses',w.document.getElementById('diagnoseZone').innerHTML.includes('Weight stalled')&&w._SYM.includes('stalled'));
w.switchTab('progress');for(const r of ['7','14','90','phase','all']){w.dispatchAct('progress.range',r);}ok('progress ranges render',w.document.getElementById('progressZone').innerHTML.includes('<svg'));
/* command palette */
w.openCmdk();w.renderCmdk('weight');ok('command palette filters and includes global search',w._CMDK_ITEMS.length>0&&w.document.getElementById('cmdkResults').innerHTML.includes('cmdk-item'));w.closeCmdk();
/* keyboard: Escape closes a sheet, L opens quick log */
w.openLog('weight');w.document.dispatchEvent(new w.KeyboardEvent('keydown',{key:'Escape',bubbles:true}));ok('Escape closes the sheet',!w._SHEET);
w.document.dispatchEvent(new w.KeyboardEvent('keydown',{key:'l',bubbles:true}));ok('L opens quick log',w._SHEET&&w._SHEET.kind==='log');w.closeSheet();
/* every data-act resolves */
const acts=[...new Set([...w.document.querySelectorAll('[data-act]')].map(e=>e.getAttribute('data-act')))];const unreg=acts.filter(a=>!w.ACTIONS[a]);ok('all '+acts.length+' data-act names in the DOM are registered',unreg.length===0,unreg.join(','));
/* in-app self-test */
const st=w.runSelfTest();st.results.filter(r=>!r.ok).forEach(r=>report.push('  FAIL  selftest: '+r.name+' — '+r.detail));ok('in-app self-test passes ('+st.passed+' checks)',st.failed===0,st.failed+' failed');
/* a11y audit on each view */
for(const t of tabs){w.switchTab(t);const au=w.runA11yAudit();const bad=au.issues.filter(i=>i.kind==='unnamed control'||i.kind==='dialog without label'||i.kind==='positive tabindex');ok('a11y '+t+': no unnamed controls / unlabeled dialogs',bad.length===0,bad.slice(0,3).map(i=>i.kind+':'+i.el).join('; '));}
/* persistence round trip through the localStorage mirror */
const rev=w.DB.revision;w.save('test');const raw=w.localStorage.getItem('physiqueOS_db_v1');ok('save mirrors to localStorage with the new revision',raw&&JSON.parse(raw).revision===rev+1);
/* exports */
ok('state report exports',w.stateReport().includes('DECISION:'));ok('CSV exports',w.exportCSV('training').split('\n').length>5);
/* empty record */
w.dispatchAct('demo.reset');await sleep(5);w.resolveConfirm(true);await sleep(20);ok('reset produces an empty record and SETUP decision',w.DB.observations.length===0&&w.decide().code==='SETUP');
for(const t of tabs){const before=w.getSwallowedErrors().count;w.switchTab(t);ok('empty view '+t+' renders',w.getSwallowedErrors().count===before);}
ok('no quarantined errors overall',w.getSwallowedErrors().count===0,JSON.stringify(w.getSwallowedErrors().top.slice(0,5)));
ok('no jsdom runtime errors overall',consoleErrors.length===0,consoleErrors.slice(0,3).join(' | '));
console.log(report.join('\n'));console.log('\n'+(report.length-failures)+' passed, '+failures+' failed');
process.exit(failures?1:0);
